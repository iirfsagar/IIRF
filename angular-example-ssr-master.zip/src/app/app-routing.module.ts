import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './modules/home/home.component';
import { MbaCollegesDetailsComponent } from './modules/mba-colleges-details/mba-colleges-details.component';
import { PrivacyPolicyComponent } from './modules/privacy-policy/privacy-policy.component';
import { TermsAndConditionsComponent } from './modules/terms-and-conditions/terms-and-conditions.component';
import { WhoIsWhoDetailsComponent } from './modules/whoiswho/who-is-who-details-page/who-is-who-details-page.component';

const routes: Routes = [
  {
    path: '', 
    component: HomeComponent,
    data: {
      title: 'IIRF Ranking: Top Universities, Engineering Colleges, B-Schools, Law Colleges, Design schools & Architecture Colleges in India',
      descrption: 'IIRF Ranks 1000+ Institutions comprising more than 300 universities, 100+ UG colleges for BBA and BCA, 350 Engineering Colleges, 50 Architecture Colleges, 50 Design Institutions, 50 Law Colleges, and more than 150 B-Schools from all over India.',
      ogTitle: 'IIRF Ranking: Top Universities, Engineering Colleges, B-Schools, Law Colleges, Design schools & Architecture Colleges in India',
      keywords: 'iirf ranking, universities rank, engineering colleges ranking, architecture colleges ranking, design colleges ranking, law colleges ranking',
    }
  },   

  {path: 'terms-and-conditions', component: TermsAndConditionsComponent,
  data: {
    title: 'Terms and Conditions - IIRF',
    descrption: 'TERMS AND CONDITIONS Your website may use the Terms and Conditions given below. The terms “We” / “Us” / “Our”/”Company” individually and collectively refer to https://iirfranking.com/ and the terms “Visitor” ”User” refer to the users. This page states the Terms and Conditions under which you (Visitor) may visit this website (“Website”). Please read this page carefully. If […]',
    ogTitle: 'Terms and Conditions - IIRF',
  }
},
  {path: 'privacy-policy', component: PrivacyPolicyComponent,
  data: { 
    title: 'Privacy Policy - IIRF Ranking',
    descrption: 'This privacy policy sets high regard for your privacy that indicates how iirfranking.com uses and protects any information that you give, while using the website.',
    ogTitle: 'Privacy Policy - IIRF Ranking',
  }},  

{  
  path: 'adminssion-update', 
  loadChildren: () => import('./modules/adminssion/adminssion.module').then(m => m.AdminssionModule) 
},
{
  path: 'about-us',  
  loadChildren: () => import('./modules/about/about-routing.module').then(m => m.AboutRoutingModule)
}, 
{
  path: 'iirf-methodology', 
  loadChildren: () => import('./modules/methodology-module/methodology-module.module').then(m => m.MethodologyModuleModule)
},
{
  path: 'contact', 
  loadChildren: () => import('./modules/contact/contact.module').then(m => m.ContactModule)
}, 
{
  path: 'top-100-private-b-schools', 
  loadChildren: () => import('./modules/top-private-b-schools/top-private-b-schools.module').then(m => m.TopPrivateBSchoolsModule)
},
{
  path: 'top-mba-colleges-india', 
  loadChildren: () => import('./modules/mba-ranking/mba-ranking.module').then(m => m.MbaRankingModule)
},
{path: 'top-mba-colleges-india/:id', component: MbaCollegesDetailsComponent,
data: { 
  title: 'Top MBA Colleges/ B Schools in India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
  descrption: 'List of Top 10, 20, 50 and 100 MBA Colleges in India 2021: 1. Indian Institute of Management, Ahmedabad, Indian Institute of Management, Kolkata,  Indian Institute of Management, Bengaluru, Faculty of Management Studies, University of Delhi. 2. Indian School Of Business, Hyderabad...',
  ogTitle: 'Top MBA Colleges/ B Schools in India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
  keywords: 'top mba colleges, mba colleges in india, best schools, top b schools, mba ranking 2021, mba admission, mba placement, mba cutoff',
}},  
{
  path: 'school-of-eminence', 
  loadChildren: () => import('./modules/school-eminence/school-eminence.module').then(m => m.SchoolEminenceModule)
},
{
  path: 'best-b-schools-north-india', 
  loadChildren: () => import('./modules/b-school-north/b-school-north.module').then(m => m.BSchoolNorthModule)
},
{
  path: 'best-b-schools-south-india', 
  loadChildren: () => import('./modules/b-school-south/b-school-south.module').then(m => m.BSchoolSouthModule)
},
{
  path: 'best-b-schools-central-india', 
  loadChildren: () => import('./modules/b-school-central-module/b-school-central-module.module').then(m => m.BschoolCenterlModuleModule)
},
{
  path: 'best-b-schools-west-india', 
  loadChildren: () => import('./modules/b-school-west/b-school-west.module').then(m => m.BSchoolWestModule)
},
{
  path: 'best-b-schools-east-india', 
  loadChildren: () => import('./modules/b-school-east/b-school-east.module').then(m => m.BSchoolEastgModule)
},
{ 
  path: 'ranking', 
  loadChildren: () => import('./modules/ranking/rankings.module').then(m => m.RankingsModule)
},
{ 
  path: 'who-is-who', 
  loadChildren: () => import('./modules/whoiswho/who-is-who.module').then(m => m.WhoIsWhoModule)
},
{ 
  path: 'add-who-is-who', 
  loadChildren: () => import('./modules/addwhoiswho/Add-who-is-who.module').then(m => m.AddWhoIsWhoModule)
},
{path: 'who-is-who/:id', component: WhoIsWhoDetailsComponent},
];
   
@NgModule({  
  imports: [RouterModule.forRoot(routes, {
    initialNavigation: 'enabled' 
})],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'mbadata'
})
export class ReturnSymbolPipe implements PipeTransform {

  transform(businessschools: string, ...args: unknown[]): unknown {
    console.log('Pipe data');
    if(businessschools == 'businessschools'){
      return 'Hello'
    }else if(businessschools == 'epoo'){
      return 'epoo'
    }else{
      return 'end'
    }
  }

}

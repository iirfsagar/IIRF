import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MethodologyComponent } from './methodology.component';
import { MethodologyModuleRoutingModule } from './methodology-module-routing.module';


@NgModule({
  imports: [
    CommonModule,
    MethodologyModuleRoutingModule
  ],
  exports: [
    MethodologyComponent
  ],
  declarations: [
    MethodologyComponent
  ],
})
export class MethodologyModuleModule { }

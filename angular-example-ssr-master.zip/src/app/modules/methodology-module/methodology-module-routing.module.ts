import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MethodologyComponent } from './methodology.component';

const routes: Routes = [
  {path: '', component: MethodologyComponent,
  data: {
    title: 'Indian Institutional Ranking Framework (IIRF) Ranking Methodology',
    descrption: 'IIRF Ranking has experts from education, academics, statistics and management, who discuss and develop ranking methodology and approach.',
    ogTitle: 'Indian Institutional Ranking Framework (IIRF) Ranking Methodology',
  }
},
];

@NgModule({
  imports: [RouterModule.forChild(routes)], 
  exports: [RouterModule]
})
export class MethodologyModuleRoutingModule { }

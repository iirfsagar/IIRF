import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { Meta, MetaDefinition } from '@angular/platform-browser';
@Component({
  selector: 'app-methodology',
  templateUrl: './methodology.component.html',
  styleUrls: ['./methodology.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class MethodologyComponent implements OnInit {

  constructor(private metaService: Meta) {

   }

  ngOnInit(): void {

  }

}

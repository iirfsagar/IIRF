import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MbaRankingComponent } from './mba-ranking.component';
import { MbaRankingRoutingModule } from './mba-ranking-routing.module';
import { DataTablesModule } from "angular-datatables";
import {MatExpansionModule} from '@angular/material/expansion';

@NgModule({
  imports: [
    CommonModule,
    MbaRankingRoutingModule,
    DataTablesModule,
    MatExpansionModule
  ], 
  exports: [
    MbaRankingComponent  
  ], 
  declarations: [
    MbaRankingComponent
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ] 
})
export class MbaRankingModule { } 
   
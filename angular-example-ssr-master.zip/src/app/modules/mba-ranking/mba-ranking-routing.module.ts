import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MbaRankingComponent } from './mba-ranking.component';


const routes: Routes = [
  {path: '', component: MbaRankingComponent,
  data: {
    title: 'Top MBA Colleges/ B Schools in India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    descrption: 'List of Top 10, 20, 50 and 100 MBA Colleges in India 2021: 1. Indian Institute of Management, Ahmedabad, Indian Institute of Management, Kolkata,  Indian Institute of Management, Bengaluru, Faculty of Management Studies, University of Delhi. 2. Indian School Of Business, Hyderabad...',
    ogTitle: 'Top MBA Colleges/ B Schools in India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    keywords: 'top mba colleges, mba colleges in india, best schools, top b schools, mba ranking 2021, mba admission, mba placement, mba cutoff',
  }}, 

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MbaRankingRoutingModule { }

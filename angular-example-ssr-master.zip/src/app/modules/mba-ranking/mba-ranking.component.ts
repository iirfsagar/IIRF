import {AfterViewInit, Component, ViewChild , OnInit, ChangeDetectionStrategy} from '@angular/core';
import { MbaRankingService } from '../service/mba-ranking.service';
import { MbaRanking } from '../model/admisson-model';

@Component({
  selector: 'app-mba-ranking',
  templateUrl: './mba-ranking.component.html',
  styleUrls: ['./mba-ranking.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class MbaRankingComponent implements OnInit{
  
  panelOpenState = false;

  mbaaRanking: MbaRanking[] = [];
   
  constructor(public _mbaRanking: MbaRankingService) { 
  } 
  ngOnInit(): void {
    this._mbaRanking.getMbaRanking().subscribe(
      res =>{
        this.mbaaRanking = res['2'].data; 
      }
    )
  }

}

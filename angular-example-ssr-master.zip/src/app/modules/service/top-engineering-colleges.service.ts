import { Injectable } from '@angular/core';
import { TopEngineeringColleges, TopPrivateEngineeringColleges} from '../model/admisson-model';
import { HttpClient , HttpErrorResponse, HttpHeaders} from "@angular/common/http";
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TopEngineeringCollegesService {

  private topEngineeringColleges: TopEngineeringColleges[] = [];
  private topEngineeringCollegesUpdated = new Subject<TopEngineeringColleges[]>();

  private topPrivateEngineeringColleges: TopPrivateEngineeringColleges[] = [];
  private topPrivateEngineeringCollegesUpdated = new Subject<TopPrivateEngineeringColleges[]>();

  private topEngineeringCollegesUrl = 'http://184.168.122.90:3000/routers/topengineeringcolleges/';
  private topPrivateEngineeringCollegesUrl = 'http://184.168.122.90:3000/routers/topprivateengineeringcolleges/';
  
  private httpOptions;

  constructor(private http: HttpClient) { 
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        // 'Access-Control-Allow-Origin': '*',
      })
    };
  }

  getTopEngineeringColleges(): Observable<TopEngineeringColleges[]>{
    return this.http.get<TopEngineeringColleges[]>(this.topEngineeringCollegesUrl, this.httpOptions).pipe(
      map(data => {
        const topEngineeringColleges: Array<TopEngineeringColleges> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            topEngineeringColleges.push(data[id]);
          }
        }
        return topEngineeringColleges;
      })
    )
  }

  getTopPrivateEngineeringColleges(): Observable<TopPrivateEngineeringColleges[]>{
    return this.http.get<TopPrivateEngineeringColleges[]>(this.topPrivateEngineeringCollegesUrl, this.httpOptions).pipe(
      map(data => {
        const topPrivateEngineeringColleges: Array<TopPrivateEngineeringColleges> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            topPrivateEngineeringColleges.push(data[id]);
          }
        }
        return topPrivateEngineeringColleges;
      })
    )
  }
}

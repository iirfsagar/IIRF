import { Injectable } from '@angular/core';
import { bSchoolCentralRanking, bSchoolCentralScores } from '../model/admisson-model';
import { HttpClient , HttpErrorResponse, HttpHeaders} from "@angular/common/http";
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BSchoolCentralService {

  private eminenceRanking: bSchoolCentralRanking[] = [];
  private eminenceRankingUpdated = new Subject<bSchoolCentralRanking[]>();

  private eminenceScores: bSchoolCentralScores[] = [];
  private eminenceScoresUpdated = new Subject<bSchoolCentralScores[]>();

  private bSchoolRankingUrl = 'http://184.168.122.90:3000/routers/bschoolcentralranking/';
  private bSchoolScoresUrl = 'http://184.168.122.90:3000/routers/bschoolcentralscores/';
  
  private httpOptions;

  constructor(private http: HttpClient) { 
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        // 'Access-Control-Allow-Origin': '*',
      })
    };
  }

  getbSchoolRanking(): Observable<bSchoolCentralRanking[]>{
    return this.http.get<bSchoolCentralRanking[]>(this.bSchoolRankingUrl, this.httpOptions).pipe(
      map(data => {
        const eminenceRankings: Array<bSchoolCentralRanking> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            eminenceRankings.push(data[id]);
          }
        }
        return eminenceRankings;
      })
    )
  }
   

  getbSchoolScores(): Observable<bSchoolCentralScores[]>{
    return this.http.get<bSchoolCentralScores[]>(this.bSchoolScoresUrl, this.httpOptions).pipe(
      map(data => {
        const eminenceScoress: Array<bSchoolCentralScores> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            eminenceScoress.push(data[id]);
          }
        }
        return eminenceScoress;
      })
    )
  }

  // getbSchoolRanking(){
  //   return this.http.get(this.bSchoolRankingUrl, this.httpOptions)
  // }
  // getbSchoolScores(){
  //   return this.http.get(this.bSchoolScoresUrl, this.httpOptions)
  // }
}

import { Injectable } from '@angular/core';
import { bSchoolSouthScores , bSchoolSouthRanking} from '../model/admisson-model';
import { HttpClient , HttpErrorResponse, HttpHeaders} from "@angular/common/http";
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Subject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class BSchoolSouthService {
  private eminenceRanking: bSchoolSouthRanking[] = [];
  private eminenceRankingUpdated = new Subject<bSchoolSouthRanking[]>();

  private eminenceScores: bSchoolSouthScores[] = [];
  private eminenceScoresUpdated = new Subject<bSchoolSouthScores[]>();

  private bSchoolRankingUrl = 'http://184.168.122.90:3000/routers/bschoolsouthranking/';
  private bSchoolScoresUrl = 'http://184.168.122.90:3000/routers/bschoolssouthscores/';
  
  private httpOptions;

  constructor(private http: HttpClient) { 
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        // 'Access-Control-Allow-Origin': '*',
      })
    };
  }


  getbSchoolRanking(): Observable<bSchoolSouthRanking[]>{
    return this.http.get<bSchoolSouthRanking[]>(this.bSchoolRankingUrl, this.httpOptions).pipe(
      map(data => {
        const eminenceRankings: Array<bSchoolSouthRanking> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            eminenceRankings.push(data[id]);
          }
        }
        return eminenceRankings;
      })
    )
  }
   

  getbSchoolScores(): Observable<bSchoolSouthScores[]>{
    return this.http.get<bSchoolSouthScores[]>(this.bSchoolScoresUrl, this.httpOptions).pipe(
      map(data => {
        const eminenceScoress: Array<bSchoolSouthScores> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            eminenceScoress.push(data[id]);
          }
        }
        return eminenceScoress;
      })
    )
  }


  // getbSchoolRanking(){
  //   return this.http.get(this.bSchoolRankingUrl, this.httpOptions)
  // }
  // getbSchoolScores(){
  //   return this.http.get(this.bSchoolScoresUrl, this.httpOptions)
  // }
}

import { Injectable } from '@angular/core';
import { HttpClient , HttpHeaders} from "@angular/common/http";
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BlogService {
  private blogUrl = 'https://iirfranking.com/wp-json/wp/v2/posts?_embed';
  private articlesUrl = 'https://iirfranking.com/wp-json/wp/v2/posts?categories=238&_embed&author';
  private interviewUrl = 'https://iirfranking.com/wp-json/wp/v2/posts?categories=239&_embed&author';
  private httpOptions;

  constructor(private http: HttpClient) {
    this.httpOptions = {
      headers: new HttpHeaders({
        // 'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      })
    };
   }
getBlog(): Observable<any[]>{
  return this.http.get<any[]>(this.blogUrl,{
  params: {
    per_page: '6'
  }
}
  )}
  getArticles(): Observable<any[]>{
    return this.http.get<any[]>(this.articlesUrl,{

  }
    )}
    getInterview(): Observable<any[]>{
      return this.http.get<any[]>(this.interviewUrl,{

    }
      )}

}

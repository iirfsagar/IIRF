import { Injectable } from '@angular/core';
import { SchoolofEminence, SchoolofPerformance } from '../model/admisson-model';
import { HttpClient , HttpErrorResponse, HttpHeaders} from "@angular/common/http";
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Subject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class TopSchoolsService {
  private schoolofEminence: SchoolofEminence[] = [];
  private schoolofEminenceUpdated = new Subject<SchoolofEminence[]>();
  private schoolofPerformance: SchoolofPerformance[] = [];
  private schoolofPerformanceUpdated = new Subject<SchoolofPerformance[]>();
  private schoolofPerformanceUrl = 'http://184.168.122.90:3000/routers/schoolofperformance/';
  private schoolofEminenceUrl = 'http://184.168.122.90:3000/routers/schoolofeminence/';
  
  private httpOptions;


  constructor(private http: HttpClient) {
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        // 'Access-Control-Allow-Origin': '*',
      })
    };
   }
   getSchoolofPerformance(): Observable<SchoolofPerformance[]>{
    return this.http.get<SchoolofPerformance[]>(this.schoolofPerformanceUrl, this.httpOptions).pipe(
      map(data => {
        const schoolofPerformance: Array<SchoolofPerformance> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            schoolofPerformance.push(data[id]);
          }
        }
        return schoolofPerformance;
      })
    )
  }
  getSchoolofEminence(): Observable<SchoolofEminence[]>{
    return this.http.get<SchoolofEminence[]>(this.schoolofEminenceUrl, this.httpOptions).pipe(
      map(data => {
        const schoolofEminence: Array<SchoolofEminence> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            schoolofEminence.push(data[id]);
          }
        }
        return schoolofEminence;
      })
    )
  }
}

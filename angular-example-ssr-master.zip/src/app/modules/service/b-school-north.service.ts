import { Injectable } from '@angular/core';
import { bSchoolNorthRanking , bSchoolNorthScores} from '../model/admisson-model';
import { HttpClient , HttpErrorResponse, HttpHeaders} from "@angular/common/http";
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BSchoolNorthService {


  private eminenceRanking: bSchoolNorthRanking[] = [];
  private eminenceRankingUpdated = new Subject<bSchoolNorthRanking[]>();

  private eminenceScores: bSchoolNorthScores[] = [];
  private eminenceScoresUpdated = new Subject<bSchoolNorthScores[]>();

  private bSchoolRankingUrl = 'http://184.168.122.90:3000/routers/bschoolnorthranking/';
  private bSchoolScoresUrl = 'http://184.168.122.90:3000/routers/bschoolsnorthscores/';
  
  private httpOptions;

  constructor(private http: HttpClient) { 
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        // 'Access-Control-Allow-Origin': '*',
      })
    };
  }

  getbSchoolRanking(): Observable<bSchoolNorthRanking[]>{
    return this.http.get<bSchoolNorthRanking[]>(this.bSchoolRankingUrl, this.httpOptions).pipe(
      map(data => {
        const eminenceRankings: Array<bSchoolNorthRanking> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            eminenceRankings.push(data[id]);
          }
        }
        return eminenceRankings;
      })
    )
  }
   

  getbSchoolScores(): Observable<bSchoolNorthScores[]>{
    return this.http.get<bSchoolNorthScores[]>(this.bSchoolScoresUrl, this.httpOptions).pipe(
      map(data => {
        const eminenceScoress: Array<bSchoolNorthScores> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            eminenceScoress.push(data[id]);
          }
        }
        return eminenceScoress;
      })
    )
  }
  // getbSchoolRanking(){
  //   return this.http.get(this.bSchoolRankingUrl, this.httpOptions)
  // }
  // getbSchoolScores(){
  //   return this.http.get(this.bSchoolScoresUrl, this.httpOptions)
  // }
}

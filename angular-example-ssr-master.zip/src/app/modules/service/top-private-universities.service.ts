import { Injectable } from '@angular/core';
import { TopPrivateUniversities , TopPrivateUniversitiesEmerging, TopDeemedUniversities} from '../model/admisson-model';
import { HttpClient , HttpErrorResponse, HttpHeaders} from "@angular/common/http";
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'  
})
export class TopPrivateUniversitiesService {
  private topDeemedUniversities: TopDeemedUniversities[] = [];
  private topDeemedUniversitiesUpdated = new Subject<TopDeemedUniversities[]>();

  private topPrivateUniversitie: TopPrivateUniversities[] = [];
  private topPrivateUniversitieUpdated = new Subject<TopPrivateUniversities[]>();

  private topPrivateUniversitiesEmerging: TopPrivateUniversitiesEmerging[] = [];
  private topPrivateUniversitiesEmergingUpdated = new Subject<TopPrivateUniversitiesEmerging[]>();

  private topPrivateUniversitiesUrl = 'http://184.168.122.90:3000/routers/topprivateuniversities/';
  private topPrivateUniversitiesEmergingUrl = 'http://184.168.122.90:3000/routers/topprivateuniversitiesemerging/';
  private topDeemedUniversitiesUrl = 'http://184.168.122.90:3000/routers/topdeemeduniversities/';
  private httpOptions;


  constructor(private http: HttpClient) {
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        // 'Access-Control-Allow-Origin': '*',
      })
    };
   }



   getTopPrivateUniversities(): Observable<TopPrivateUniversities[]>{
    return this.http.get<TopPrivateUniversities[]>(this.topPrivateUniversitiesUrl, this.httpOptions).pipe(
      map(data => {
        const topPrivateUniversities: Array<TopPrivateUniversities> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            topPrivateUniversities.push(data[id]);
          }
        }
        return topPrivateUniversities;
      })
    )
  }


  getTopPrivateUniversitiesEmerging(): Observable<TopPrivateUniversitiesEmerging[]>{
    return this.http.get<TopPrivateUniversitiesEmerging[]>(this.topPrivateUniversitiesEmergingUrl, this.httpOptions).pipe(
      map(data => {
        const topPrivateUniversitiesEmerging: Array<TopPrivateUniversitiesEmerging> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            topPrivateUniversitiesEmerging.push(data[id]);
          }
        }
        return topPrivateUniversitiesEmerging;
      })
    )
  }

  
  getTopDeemedUniversities(): Observable<TopDeemedUniversities[]>{
    return this.http.get<TopDeemedUniversities[]>(this.topDeemedUniversitiesUrl, this.httpOptions).pipe(
      map(data => {
        const topDeemedUniversities: Array<TopDeemedUniversities> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            topDeemedUniversities.push(data[id]);
          }
        }
        return topDeemedUniversities;
      })
    )
  }


  //  getTopPrivateUniversities(){
  //   return this.http.get(this.topPrivateUniversitiesUrl, this.httpOptions)
  // }
  // getTopPrivateUniversitiesEmerging(){
  //   return this.http.get(this.topPrivateUniversitiesEmergingUrl, this.httpOptions)
  // }
  // getTopDeemedUniversities(){
  //   return this.http.get(this.topDeemedUniversitiesUrl, this.httpOptions)
  // }
  getTopDeemedUniversitiesId(id){
    return this.http.get(this.topDeemedUniversitiesUrl + id, this.httpOptions)
  }
  addTopDeemedUniversities(rank: string, nameofinstitutes: string, city: string, state: string, content: string, address: string,img: string,){
    const cou: TopDeemedUniversities = {id: null, rank: rank, nameofinstitutes: nameofinstitutes, city: city, state: state,content: content, address: address, img: img}
    this.http.post<{message: string}>(this.topDeemedUniversitiesUrl, cou).subscribe((res)=>{
    console.log(res.message);
    this.topDeemedUniversities.push(cou);
    this.topDeemedUniversitiesUpdated.next([...this.topDeemedUniversities]);
    });
  
  }
}

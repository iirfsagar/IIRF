import { Injectable } from '@angular/core';
import { bSchoolWestScores, bSchoolWestRanking} from '../model/admisson-model';
import { HttpClient , HttpErrorResponse, HttpHeaders} from "@angular/common/http";
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BSchoolWestService {

  private eminenceRanking: bSchoolWestRanking[] = [];
  private eminenceRankingUpdated = new Subject<bSchoolWestRanking[]>();

  private eminenceScores: bSchoolWestScores[] = [];
  private eminenceScoresUpdated = new Subject<bSchoolWestScores[]>();

  private bSchoolRankingUrl = 'http://184.168.122.90:3000/routers/bschoolwestranking/';
  private bSchoolScoresUrl = 'http://184.168.122.90:3000/routers/bschoolwestscores/';
  
  private httpOptions;

  constructor(private http: HttpClient) { 
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        // 'Access-Control-Allow-Origin': '*',
      })
    };
  }

  getbSchoolRanking(): Observable<bSchoolWestRanking[]>{
    return this.http.get<bSchoolWestRanking[]>(this.bSchoolRankingUrl, this.httpOptions).pipe(
      map(data => {
        const eminenceRankings: Array<bSchoolWestRanking> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            eminenceRankings.push(data[id]);
          }
        }
        return eminenceRankings;
      })
    )
  }
   

  getbSchoolScores(): Observable<bSchoolWestScores[]>{
    return this.http.get<bSchoolWestScores[]>(this.bSchoolScoresUrl, this.httpOptions).pipe(
      map(data => {
        const eminenceScoress: Array<bSchoolWestScores> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            eminenceScoress.push(data[id]);
          }
        }
        return eminenceScoress;
      })
    )
  }
  // getbSchoolRanking(){
  //   return this.http.get(this.bSchoolRankingUrl, this.httpOptions)
  // }
  // getbSchoolScores(){
  //   return this.http.get(this.bSchoolScoresUrl, this.httpOptions)
  // }
}

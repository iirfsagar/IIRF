import { Injectable } from '@angular/core';
import {DesignSchoolsPvt, DesignSchoolsGovt } from '../model/admisson-model';
import { HttpClient , HttpErrorResponse, HttpHeaders} from "@angular/common/http";
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Subject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class DesignschoolsService {
  private _designSchoolsPvt: DesignSchoolsPvt[] = [];
  private designSchoolsPvtUpdated = new Subject<DesignSchoolsPvt[]>();

  private _designSchoolsGovt: DesignSchoolsGovt[] = [];
  private designSchoolsGovtUpdated = new Subject<DesignSchoolsGovt[]>();

  private designSchoolsPvt = 'http://184.168.122.90:3000/routers/designschoolsprivate/';
  private designSchoolsGovt = 'http://184.168.122.90:3000/routers/designschoolsgovt/';
  private httpOptions;

  constructor(private http: HttpClient) { 
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        // 'Access-Control-Allow-Origin': '*',
      })
    };
  }

  getDesignSchoolsPvt(): Observable<DesignSchoolsPvt[]>{
    return this.http.get<DesignSchoolsPvt[]>(this.designSchoolsPvt, this.httpOptions).pipe(
      map(data => {
        const designSchoolsPvt: Array<DesignSchoolsPvt> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            designSchoolsPvt.push(data[id]);
          }
        }
        return designSchoolsPvt;
      })
    )
  }

  getDesignSchoolsGovt(): Observable<DesignSchoolsGovt[]>{
    return this.http.get<DesignSchoolsGovt[]>(this.designSchoolsGovt, this.httpOptions).pipe(
      map(data => {
        const designSchoolsGovt: Array<DesignSchoolsGovt> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            designSchoolsGovt.push(data[id]);
          }
        }
        return designSchoolsGovt;
      })
    )
  }

}

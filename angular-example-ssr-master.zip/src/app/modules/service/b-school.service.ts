import { Injectable } from '@angular/core';
import { bSchoolsRanking , bSchoolsScores } from '../model/admisson-model';
import { HttpClient , HttpErrorResponse, HttpHeaders} from "@angular/common/http";
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BSchoolService {

  private eminenceRanking: bSchoolsRanking[] = [];
  private eminenceRankingUpdated = new Subject<bSchoolsRanking[]>();

  private eminenceScores: bSchoolsScores[] = [];
  private eminenceScoresUpdated = new Subject<bSchoolsScores[]>();

  private bSchoolRankingUrl = 'http://184.168.122.90:3000/routers/bschoolsranking/';
  private bSchoolScoresUrl = 'http://184.168.122.90:3000/routers/bschoolsscores/';
  
  private httpOptions;

  constructor(private http: HttpClient) { 
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        // 'Access-Control-Allow-Origin': '*',
      })
    };
  }

  
  getbSchoolRanking(): Observable<bSchoolsRanking[]>{
    return this.http.get<bSchoolsRanking[]>(this.bSchoolRankingUrl, this.httpOptions).pipe(
      map(data => {
        const bSchoolsRanking: Array<bSchoolsRanking> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            bSchoolsRanking.push(data[id]);
          }
        }
        return bSchoolsRanking;
      })
    )
  }

  getbSchoolScores(): Observable<bSchoolsScores[]>{
    return this.http.get<bSchoolsScores[]>(this.bSchoolScoresUrl, this.httpOptions).pipe(
      map(data => {
        const bSchoolsScores: Array<bSchoolsScores> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            bSchoolsScores.push(data[id]);
          }
        }
        return bSchoolsScores;
      })
    )
  }
  // getbSchoolRanking(){
  //   return this.http.get(this.bSchoolRankingUrl, this.httpOptions)
  // }
  // getbSchoolScores(){
  //   return this.http.get(this.bSchoolScoresUrl, this.httpOptions)
  // }
}

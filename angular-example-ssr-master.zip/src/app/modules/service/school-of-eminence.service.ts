import { Injectable } from '@angular/core';
import { EminenceRanking , EminenceScores } from '../model/admisson-model';
import { HttpClient , HttpErrorResponse, HttpHeaders} from "@angular/common/http";
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Subject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class SchoolOfEminenceService {
  private eminenceRanking: EminenceRanking[] = [];
  private eminenceRankingUpdated = new Subject<EminenceRanking[]>();

  private eminenceScores: EminenceScores[] = [];
  private eminenceScoresUpdated = new Subject<EminenceScores[]>();

  private eminenceRankingUrl = 'http://184.168.122.90:3000/routers/schoolsfeminenceranking/';
  private eminenceScoresUrl = 'http://184.168.122.90:3000/routers/schoolofeminencescores/';
  
  private httpOptions;

  constructor(private http: HttpClient) {
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        // 'Access-Control-Allow-Origin': '*',
      })
    };
   }

   getEminenceRanking(): Observable<EminenceRanking[]>{
    return this.http.get(this.eminenceRankingUrl, this.httpOptions).pipe(
      map(data => {
        const eminenceRankings: Array<EminenceRanking> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            eminenceRankings.push(data[id]);
          }
        }
        return eminenceRankings;
      })
    )
  }
   

  getEminenceScores(): Observable<EminenceScores[]>{
    return this.http.get<EminenceScores[]>(this.eminenceScoresUrl, this.httpOptions).pipe(
      map(data => {
        const eminenceScoress: Array<EminenceScores> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            eminenceScoress.push(data[id]);
          }
        }
        return eminenceScoress;
      })
    )
  }
}

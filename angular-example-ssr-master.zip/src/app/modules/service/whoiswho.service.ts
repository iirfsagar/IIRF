import { Injectable } from '@angular/core';
import { WhoIsWho , WhoIsWhoEditor, WhoIsWhoResearch, WhoIsWhoSAARC} from '../model/admisson-model';
import { HttpClient , HttpErrorResponse, HttpHeaders} from "@angular/common/http";
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Subject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class WhoIsWhoService {
  private whoIsWho: WhoIsWho[] = [];
  private whoIsWhoUpdated = new Subject<WhoIsWho[]>();

  private whoIsWhoResearch: WhoIsWhoResearch[] = [];
  private whoIsWhoResearchUpdated = new Subject<WhoIsWhoResearch[]>();

  private whoIsWhoEditor: WhoIsWhoEditor[] = [];
  private whoIsWhoEditorUpdated = new Subject<WhoIsWhoEditor[]>();

  private whoIsWhoSAARC: WhoIsWhoSAARC[] = [];
  private whoIsWhoSAARCUpdated = new Subject<WhoIsWhoSAARC[]>();

  private whoiswhoUrl = 'http://184.168.122.90:3000/routers/whoiswho/';
  private whoiswhoResearchUrl = 'http://184.168.122.90:3000/routers/whoiswhoresearch/';
  private whoiswhoEditorUrl = 'http://184.168.122.90:3000/routers/whoiswhoeditor/';
  private whoiswhoSAARCUrl = 'http://184.168.122.90:3000/routers/whoiswhosaarc/';
  
  private httpOptions;


  constructor(private http: HttpClient) {
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        // 'Access-Control-Allow-Origin': '*',
      })
    };
   }


   getWhoIsWhoSAARCData(): Observable<WhoIsWhoSAARC[]>{
    return this.http.get<WhoIsWhoSAARC[]>(this.whoiswhoSAARCUrl, this.httpOptions).pipe(
      map(data => {
        const WhoIsWhosAARC: Array<WhoIsWhoSAARC> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            WhoIsWhosAARC.push(data[id]);
          }
        }
        return WhoIsWhosAARC;
      })
    )
  }

getWhoIsWhoSAARCDataId(id){
  return this.http.get(this.whoiswhoSAARCUrl + id, this.httpOptions)
}


   getWhoIsWhoEditorData(): Observable<WhoIsWhoEditor[]>{
    return this.http.get<WhoIsWhoEditor[]>(this.whoiswhoEditorUrl, this.httpOptions).pipe(
      map(data => {
        const WhoIsWhoeditor: Array<WhoIsWhoEditor> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            WhoIsWhoeditor.push(data[id]);
          }
        }
        return WhoIsWhoeditor;
      })
    )
  }

getWhoIsWhoEditorDataId(id){
  return this.http.get(this.whoiswhoEditorUrl + id, this.httpOptions)
}



   getWhoIsWhoResearchData(): Observable<WhoIsWhoResearch[]>{
    return this.http.get<WhoIsWhoResearch[]>(this.whoiswhoResearchUrl, this.httpOptions).pipe(
      map(data => {
        const WhoIsWhoresearch: Array<WhoIsWhoResearch> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            WhoIsWhoresearch.push(data[id]);
          }
        }
        return WhoIsWhoresearch;
      })
    )
  }

getWhoIsWhoResearchDataId(id){
  return this.http.get(this.whoiswhoResearchUrl + id, this.httpOptions)
}

   getWhoIsWhoData(): Observable<WhoIsWho[]>{
    return this.http.get<WhoIsWho[]>(this.whoiswhoUrl, this.httpOptions).pipe(
      map(data => {
        const whoiswho: Array<WhoIsWho> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            whoiswho.push(data[id]);
          }
        }
        return whoiswho;
      })
    )
  }

getWhoIsWhoDataId(id){
  return this.http.get(this.whoiswhoUrl + id, this.httpOptions)
}




addWhoIsWho(title: string, content: string, subtitle: string, img: string){
  const cou: WhoIsWhoSAARC = {id: null, img: img, title: title, subtitle: subtitle, content: content}
  this.http.post<{message: string}>(this.whoiswhoSAARCUrl, cou).subscribe((res)=>{
  console.log(res.message);
  this.whoIsWhoSAARC.push(cou);
  this.whoIsWhoSAARCUpdated.next([...this.whoIsWhoSAARC]);
  });
}
}

import { Injectable } from '@angular/core';
import { ArchitectureCollegesPvt, ArchitectureCollegesGovt } from '../model/admisson-model';
import { HttpClient , HttpErrorResponse, HttpHeaders} from "@angular/common/http";
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ArchitectureCollegesService {
  private architectureCollegesPvt: ArchitectureCollegesPvt[] = [];
  private architectureCollegesPvtUpdated = new Subject<ArchitectureCollegesPvt[]>();

  private architectureCollegesGovt: ArchitectureCollegesGovt[] = [];
  private architectureCollegesGovtUpdated = new Subject<ArchitectureCollegesGovt[]>();

  private architectureCollegesPvtUrl = 'http://184.168.122.90:3000/routers/architecturecollegesprivate/';
  private architectureCollegesGovtUrl = 'http://184.168.122.90:3000/routers/architecturecollegesgovt/';
  
  private httpOptions;

  constructor(private http: HttpClient) { 
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        // 'Access-Control-Allow-Origin': '*',
      })
    }; 
  }

  getArchitectureCollegesPvt(): Observable<ArchitectureCollegesPvt[]>{
    return this.http.get<ArchitectureCollegesPvt[]>(this.architectureCollegesPvtUrl, this.httpOptions).pipe(
      map(data => {
        const architectureCollegesPvt: Array<ArchitectureCollegesPvt> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            architectureCollegesPvt.push(data[id]);
          }
        }
        return architectureCollegesPvt;
      })
    )
  }

  getArchitectureCollegesGovt(): Observable<ArchitectureCollegesGovt[]>{
    return this.http.get<ArchitectureCollegesGovt[]>(this.architectureCollegesGovtUrl, this.httpOptions).pipe(
      map(data => {
        const architectureCollegesGovt: Array<ArchitectureCollegesGovt> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            architectureCollegesGovt.push(data[id]);
          }
        }
        return architectureCollegesGovt;
      })
    )
  }

  // getArchitectureCollegesPvt(){
  //   return this.http.get(this.architectureCollegesPvtUrl, this.httpOptions)
  // }
  // getArchitectureCollegesGovt(){
  //   return this.http.get(this.architectureCollegesGovtUrl, this.httpOptions)
  // }
}

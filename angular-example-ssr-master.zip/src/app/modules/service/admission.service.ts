import { Injectable } from '@angular/core';
import { Admission } from '../model/admisson-model';
import { Observable, Subject } from 'rxjs';
import { HttpClient , HttpHeaders} from '@angular/common/http';
import { catchError, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AdmissionService {
  private admission: Admission[] = [];
  
  private admissionUpdated = new Subject<Admission[]>();
  private httpOptions;
  
  private admissionUrl = "http://184.168.122.90:3000/routers/admission/";
  constructor(private http: HttpClient) { 
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        // 'Access-Control-Allow-Origin': '*'
      })
    };
  }


  getAdmissonData(): Observable<Admission[]>{
    return this.http.get<Admission[]>(this.admissionUrl, this.httpOptions).pipe(
      map(data => {
        const admission: Array<Admission> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            admission.push(data[id]);
          }
        }
        return admission;
      })
    )
  }

getAdmissonDataId(id){
  return this.http.get(this.admissionUrl + id, this.httpOptions)
}

addAdmisson(title: string, content: string, shottitle: string, img: string){
  const cou: Admission = {id: null, title: title, content: content, img: img, shottitle: shottitle}
  this.http.post<{message: string}>(this.admissionUrl, cou).subscribe((res)=>{
  console.log(res.message);
  this.admission.push(cou);
  this.admissionUpdated.next([...this.admission]);
  });
}
}

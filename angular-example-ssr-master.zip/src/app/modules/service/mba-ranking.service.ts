import { Injectable } from '@angular/core';
import { MbaRanking } from '../model/admisson-model';
import { HttpClient , HttpErrorResponse, HttpHeaders} from "@angular/common/http";
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class MbaRankingService {

  private mbaRanking: MbaRanking[] = [];
  
  private mbaRankingUpdated = new Subject<MbaRanking[]>();

  private mbaUrl = 'http://184.168.122.90:3000/routers/mbaranking/';
  private httpOptions;
 
  constructor(private http: HttpClient) {
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
          // method: 'GET',
      })
    };
   }

   getMbaRanking(): Observable<MbaRanking[]>{
    return this.http.get<MbaRanking[]>(this.mbaUrl, this.httpOptions).pipe(
      map(data => {
        const mbaRanking: Array<MbaRanking> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            mbaRanking.push(data[id]);
          }
        }
        return mbaRanking;
      })
    )
  }
    // getMbaRanking(): Observable<MbaRanking[]> {
  //   return this.http.get<MbaRanking []>(this.mbaUrl)
  //     .pipe(
  //       tap(data =>
  //       console.log('All: ' + JSON.stringify(data)))
  //     );


  // getMbaRanking(){
  //   return this.http.get(this.mbaUrl, this.httpOptions)
  // }

  getMbaRankingId(id){
    return this.http.get(this.mbaUrl + id, this.httpOptions)
  }

  // getMbaRankingId(id): Observable<MbaRanking[]>{
  //   return this.http.get<MbaRanking[]>(this.mbaUrl + id, this.httpOptions).pipe(
  //     map(data => {
  //       const mbaRanking: Array<MbaRanking> = []
  //       for(const id in data){
  //         if(data.hasOwnProperty(id)){
  //           mbaRanking.push(data[id]);
  //         }
  //       }
  //       return mbaRanking;
  //     })
  //   )
  // }

  addMbaRanking(img: string,rank: string, businessschools: string,  weightedindex: string, placementperformance: string,tlrp: string,research: string,industryincomeintegration: string,pss: string,futureorientation: string,epio: string, iirfranking: string,address: string,content: string,)
  {
    const cou: MbaRanking = {id: null, img: img, rank: rank, businessschools: businessschools, weightedindex: weightedindex, placementperformance: placementperformance,tlrp: tlrp,research: research,industryincomeintegration: industryincomeintegration, pss: pss,  futureorientation: futureorientation, epio: epio, iirfranking: iirfranking, address: address, content: content, }
    this.http.post<{message: string}>(this.mbaUrl, cou).subscribe((res)=>{
    console.log(res.message);
    this.mbaRanking.push(cou);
    this.mbaRankingUpdated.next([...this.mbaRanking]);
    });
  
  }
  
} 
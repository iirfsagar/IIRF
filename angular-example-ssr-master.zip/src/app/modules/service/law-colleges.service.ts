import { Injectable } from '@angular/core';
import { LawCollegesPvt, LawCollegesGovt } from '../model/admisson-model';
import { HttpClient , HttpErrorResponse, HttpHeaders} from "@angular/common/http";
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LowCollegesService {
  private eminenceRanking: LawCollegesPvt[] = [];
  private eminenceRankingUpdated = new Subject<LawCollegesPvt[]>();

  private eminenceScores: LawCollegesGovt[] = [];
  private eminenceScoresUpdated = new Subject<LawCollegesGovt[]>();

  private LawCollegesPvtUrl = 'http://184.168.122.90:3000/routers/lawcollegesprivate/';
  private LawCollegesGovtUrl = 'http://184.168.122.90:3000/routers/lawcollegesgovt/';
  
  private httpOptions;


  constructor(private http: HttpClient) {
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        // 'Access-Control-Allow-Origin': '*',
      })
    };
   }


   getLawCollegesPvt(): Observable<LawCollegesPvt[]>{
    return this.http.get<LawCollegesPvt[]>(this.LawCollegesPvtUrl, this.httpOptions).pipe(
      map(data => {
        const lawCollegesPvt: Array<LawCollegesPvt> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            lawCollegesPvt.push(data[id]);
          }
        }
        return lawCollegesPvt;
      })
    )
  }

  getLawCollegesGovt(): Observable<LawCollegesGovt[]>{
    return this.http.get<LawCollegesGovt[]>(this.LawCollegesGovtUrl, this.httpOptions).pipe(
      map(data => {
        const lawCollegesGovt: Array<LawCollegesGovt> = []
        for(const id in data){
          if(data.hasOwnProperty(id)){
            lawCollegesGovt.push(data[id]);
          }
        }
        return lawCollegesGovt;
      })
    )
  }
}

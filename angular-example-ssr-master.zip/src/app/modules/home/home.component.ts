import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { BlogService } from '../service/blog.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class HomeComponent implements OnInit {
articlesData: any = [];
interviewData: any = [];
blogData: any = [];
  loading: boolean;

  constructor(public blog: BlogService) {
    this.getAllBlog();
    this.getArticles();
    this.getInterview();
   } 
   ngOnInit(): void {

  }
 

  getAllBlog(){
    this.loading = true;
    this.blog.getBlog().subscribe(response => {
      this.loading = false;
      this.blogData = response;
    });
  }

  getArticles(){
    this.loading = true;
    this.blog.getArticles().subscribe(response => {
      this.loading = false;
      this.articlesData = response;
    });
  }

  getInterview(){
    this.loading = true;
    this.blog.getInterview().subscribe(response => {
      this.loading = false;
      this.interviewData = response;
    });
  }

 
}

import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AngularEditorConfig } from '@kolkov/angular-editor';
import { MbaRankingService } from '../service/mba-ranking.service';

@Component({
  selector: 'app-addmbaranking',
  templateUrl: './addmbaranking.component.html',
  styleUrls: ['./addmbaranking.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class AddmbarankingComponent implements OnInit {

  constructor(public mbaRanking: MbaRankingService) { }

  ngOnInit(): void {
  }
  onAddPost(form: NgForm){
    if(form.invalid){
      return;
      console.log('Hello')
    }
    this.mbaRanking.addMbaRanking(form.value.img, form.value.rank, form.value.businessschools, form.value.weightedindex,form.value.placementperformance, form.value.tlrp, form.value.research ,form.value.industryincomeintegration, form.value.pss, form.value.futureorientation, form.value.epio, form.value.iirfranking,form.value.address, form.value.content );
  }


  editorConfig: AngularEditorConfig = {
    editable: true,
      spellcheck: true,
      height: '300px',
      minHeight: '500',
      maxHeight: 'auto',
      width: 'auto',
      minWidth: '0',
      translate: 'yes',
      enableToolbar: true,
      showToolbar: true,
      placeholder: 'Enter text here...',
      defaultParagraphSeparator: '',
      defaultFontName: '',
      defaultFontSize: '',
      fonts: [
        {class: 'arial', name: 'Arial'},
        {class: 'times-new-roman', name: 'Times New Roman'},
        {class: 'calibri', name: 'Calibri'},
        {class: 'comic-sans-ms', name: 'Comic Sans MS'}
      ],
      customClasses: [
      {
        name: 'quote',
        class: 'quote',
      },
      {
        name: 'redText',
        class: 'redText'
      },
      {
        name: 'titleText',
        class: 'titleText',
        tag: 'h1',
      },
    ],
    uploadUrl: 'v1/image',
    uploadWithCredentials: false,
    sanitize: true,
    toolbarPosition: 'top',
    toolbarHiddenButtons: [
      // ['bold', 'italic'],
      // ['fontSize']
    ]
};
}

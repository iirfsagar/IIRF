import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { MbaRankingService } from '../service/mba-ranking.service';


@Component({
  selector: 'app-mba-colleges-details',
  templateUrl: './mba-colleges-details.component.html',
  styleUrls: ['./mba-colleges-details.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class MbaCollegesDetailsComponent implements OnInit {
  content_id: any = '';
  admissionData: any = [];

  constructor(private activatRoute: ActivatedRoute,  private http: HttpClient, public admissionService: MbaRankingService) {
    
   }
 
  ngOnInit(): void {
    this.content_id = this.activatRoute.snapshot.params['id']
    this.getDataDetails();

    this.admissionService.getMbaRankingId(this.content_id).subscribe((res) => {
      this.admissionData = res['data'].doc
      // console.log(res)
    })
  }

  getDataDetails(){
 
  }

}

import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SchoolEminenceComponent } from './school-eminence.component';
import { SchoolEminenceRoutingModule } from './school-eminence-routing.module';
import { DataTablesModule } from "angular-datatables";

@NgModule({
  imports: [
    CommonModule,
    SchoolEminenceRoutingModule,
    DataTablesModule
  ], 
  exports: [
    SchoolEminenceComponent  
  ],
  declarations: [
    SchoolEminenceComponent
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ] 
})
export class SchoolEminenceModule { } 
  
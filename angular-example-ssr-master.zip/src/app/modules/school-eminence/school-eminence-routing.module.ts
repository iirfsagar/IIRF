import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SchoolEminenceComponent } from './school-eminence.component';


const routes: Routes = [
  {path: '', component: SchoolEminenceComponent,
  data: {
    title: 'Top Eminence Schools/ Colleges/ Institutes in India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    descrption: 'IIRF MBA Ranking 2021 helps you to decide which Eminence School you should apply to on the best available options. List of  Top Eminence Schools/ Institutes/ Colleges in India 2021: 1. Indian School of Business, 2. Xavier Labour Relations Institute, 3. Management Development Institute, 4. S P Jain Institute of Management And Research',
    ogTitle: 'Top Eminence Schools/ Colleges/ Institutes in India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    keywords: 'top eminence schools in india, eminence college, eminence institutes, institute of eminence, institute of eminence india',
  }},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SchoolEminenceRoutingModule { }

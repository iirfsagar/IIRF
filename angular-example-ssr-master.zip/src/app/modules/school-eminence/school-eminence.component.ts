import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { EminenceRanking, EminenceScores } from '../model/admisson-model';
import { SchoolOfEminenceService } from '../service/school-of-eminence.service';

@Component({
  selector: 'app-school-eminence',
  templateUrl: './school-eminence.component.html',
  styleUrls: ['./school-eminence.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class SchoolEminenceComponent implements OnInit {
   EminenceRanking: EminenceRanking[] = [];
   EminenceScores: EminenceScores[] = [];
    
  constructor(public eminenceRanking: SchoolOfEminenceService) {
   }
  ngOnInit(): void {
    this.eminenceRanking.getEminenceRanking().subscribe((res)=>{
      this.EminenceRanking = res['2'].data;
      // console.log(res)
    })
    this.eminenceRanking.getEminenceScores().subscribe((res)=>{
      this.EminenceScores = res['2'].data;
      // console.log(res)
    })

  }

}

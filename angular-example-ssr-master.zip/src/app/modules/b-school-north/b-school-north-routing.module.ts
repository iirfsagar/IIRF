import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BSchoolNorthComponent } from './b-school-north.component';


const routes: Routes = [
  {path: '', component: BSchoolNorthComponent,
  data: {
    title: 'Top MBA Colleges/ Best B-School in North, India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    descrption: 'IIRF MBA Ranking 2021 helps you to decide which MBA College/ B School you should apply to on the best available options. List of Top MBA Colleges/ B-School in North, India 2021: 1. Management Development Institute, 2. Institute of Management Technology, 3. International Management Institute, 4. FORE School of Management...',
    ogTitle: 'Top MBA Colleges/ Best B-School in North, India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    keywords: 'top mba colleges in north india, b schools in north india, top 100 mba colleges in north india, top 10 mba colleges in north india, top colleges for mba in north india, top private b schools in north india, top mba colleges in north east india',
  }},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BSchoolNorthRoutingModule { }

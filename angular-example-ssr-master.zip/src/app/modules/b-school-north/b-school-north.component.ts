import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { BSchoolNorthService } from '../service/b-school-north.service';
import { bSchoolNorthRanking , bSchoolNorthScores} from '../model/admisson-model';
@Component({
  selector: 'app-b-school-north',
  templateUrl: './b-school-north.component.html',
  styleUrls: ['./b-school-north.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class BSchoolNorthComponent implements OnInit {
  bSchoolNorthRanking: bSchoolNorthRanking[] = [];
  bSchoolNorthScores: bSchoolNorthScores[] = [];
  constructor(public bSchoolNorth: BSchoolNorthService) {
   }

  ngOnInit(): void {
    this.bSchoolNorth.getbSchoolRanking().subscribe((res)=>{
      this.bSchoolNorthRanking = res['2'].data;
    })
    this.bSchoolNorth.getbSchoolScores().subscribe((res)=>{
      this.bSchoolNorthScores = res['2'].data;
    })
  }
}

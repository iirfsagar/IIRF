import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BSchoolNorthComponent } from './b-school-north.component';
import { BSchoolNorthRoutingModule } from './b-school-north-routing.module';
import { DataTablesModule } from "angular-datatables";

@NgModule({
  imports: [
    CommonModule,
    BSchoolNorthRoutingModule,
    DataTablesModule
  ], 
  exports: [
    BSchoolNorthComponent   
  ],
  declarations: [
    BSchoolNorthComponent
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ] 
})
export class BSchoolNorthModule { } 
  
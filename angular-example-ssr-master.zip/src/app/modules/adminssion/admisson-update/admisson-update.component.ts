import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { AdmissionService } from '../../service/admission.service';
import { HttpClient } from '@angular/common/http';
import { Admission } from '../../model/admisson-model';

@Component({
  selector: 'app-admisson-update',
  templateUrl: './admisson-update.component.html',
  styleUrls: ['./admisson-update.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class AdmissonUpdateComponent implements OnInit {
  admission: Admission[] = [];
  constructor(public admissionService: AdmissionService, private http: HttpClient) {
   }

  ngOnInit(): void { 
    this.admissionService.getAdmissonData().subscribe((res)=>{
      this.admission = res['2'].data; 
    })
  }  
}

import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AngularEditorConfig } from '@kolkov/angular-editor';
import { AdmissionService } from '../../service/admission.service';

@Component({
  selector: 'app-add-admisson-page',
  templateUrl: './add-admisson-page.component.html',
  styleUrls: ['./add-admisson-page.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class AddAdmissonPageComponent implements OnInit {

  constructor(public admissionService: AdmissionService) { }

  ngOnInit(): void {
  }
  onAddPost(form: NgForm){
    if(form.invalid){
      return;
      console.log('Hello')
    }
    this.admissionService.addAdmisson(form.value.title, form.value.content, form.value.shottitle, form.value.img);
  }
  editorConfig: AngularEditorConfig = {
    editable: true,
      spellcheck: true,
      height: '300px',
      minHeight: '500',
      maxHeight: 'auto',
      width: 'auto',
      minWidth: '0',
      translate: 'yes',
      enableToolbar: true,
      showToolbar: true,
      placeholder: 'Enter text here...',
      defaultParagraphSeparator: '',
      defaultFontName: '',
      defaultFontSize: '',
      fonts: [
        {class: 'arial', name: 'Arial'},
        {class: 'times-new-roman', name: 'Times New Roman'},
        {class: 'calibri', name: 'Calibri'},
        {class: 'comic-sans-ms', name: 'Comic Sans MS'}
      ],
      customClasses: [
      {
        name: 'quote',
        class: 'quote',
      },
      {
        name: 'redText',
        class: 'redText'
      },
      {
        name: 'titleText',
        class: 'titleText',
        tag: 'h1',
      },
    ],
    uploadUrl: 'v1/image',
    uploadWithCredentials: false,
    sanitize: true,
    toolbarPosition: 'top',
    toolbarHiddenButtons: [
      // ['bold', 'italic'],
      // ['fontSize']
    ]
};
}

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddAdmissonPageComponent } from './add-admisson-page/add-admisson-page.component';
import { AdmissionUpdateDetailsComponent } from './admission-update-details/admission-update-details.component';
import { AdmissonUpdateComponent } from './admisson-update/admisson-update.component';

const routes: Routes = [
      {path: '', component: AdmissonUpdateComponent}, 
      {path: 'adminssion-update', component: AdmissonUpdateComponent}, 
      {path: 'adminssion-update/:id', component: AdmissionUpdateDetailsComponent},
      {path: 'app-admisson', component: AddAdmissonPageComponent},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminssionRoutingModule { }

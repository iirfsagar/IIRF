import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminssionRoutingModule } from './adminssion-routing.module';

import { AdmissonUpdateComponent } from './admisson-update/admisson-update.component';
import { AdmissionUpdateDetailsComponent } from './admission-update-details/admission-update-details.component';


@NgModule({
  imports: [
    CommonModule,
    AdminssionRoutingModule,
  ],
  declarations: [ 
    AdmissonUpdateComponent,
    AdmissionUpdateDetailsComponent
  ],
  exports: [
    AdmissonUpdateComponent,
    AdmissionUpdateDetailsComponent
  ],

})
export class AdminssionModule { }

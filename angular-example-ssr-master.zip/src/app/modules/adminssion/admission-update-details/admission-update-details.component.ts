import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { AdmissionService } from '../../service/admission.service';

@Component({
  selector: 'app-admission-update-details',
  templateUrl: './admission-update-details.component.html',
  styleUrls: ['./admission-update-details.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class AdmissionUpdateDetailsComponent implements OnInit {
  content_id: any = '';
  admissionData: any = [];
  constructor(private activatRoute: ActivatedRoute,  private http: HttpClient, public admissionService: AdmissionService) {
    
   }
  ngOnInit(): void {
    this.content_id = this.activatRoute.snapshot.params['id']
    this.admissionService.getAdmissonDataId(this.content_id).subscribe((res) => {
      this.admissionData = res['data'].doc;
      // console.log(res)
    })
  }

}

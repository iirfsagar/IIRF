import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MbbsCollegesComponent } from './mbbs-colleges.component';


const routes: Routes = [
  {path: '', component: MbbsCollegesComponent,
  data: {
    title: 'Top MBBS Colleges in India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    descrption: 'View Top MBBS College in India 2021. See list of Top 10, 20, 50 & 100 top medical colleges in India by IIRF. Check Ranking, Admission, Placement, Fees, Cutoffs and Eligibility of Medical Colleges for 2021.',
    ogTitle: 'Top MBBS Colleges in India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    keywords: 'top mbbs college in india, top private mbbs college in india, top 10 college for mbbs in india, top mbbs government college in india',
  }},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MbbsCollegesRoutingModule { }

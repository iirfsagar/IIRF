import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MbbsCollegesComponent } from './mbbs-colleges.component';
import { MbbsCollegesRoutingModule } from './mbbs-colleges-routing.module';
import { DataTablesModule } from "angular-datatables";

@NgModule({
  imports: [
    CommonModule,
    MbbsCollegesRoutingModule,
    DataTablesModule
  ], 
  exports: [
    MbbsCollegesComponent  
  ],
  declarations: [
    MbbsCollegesComponent
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ] 
})
export class MbbsCollegesModule { } 
  
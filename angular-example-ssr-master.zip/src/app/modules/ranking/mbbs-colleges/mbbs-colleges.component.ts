import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mbbs-colleges',
  templateUrl: './mbbs-colleges.component.html',
  styleUrls: ['./mbbs-colleges.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class MbbsCollegesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

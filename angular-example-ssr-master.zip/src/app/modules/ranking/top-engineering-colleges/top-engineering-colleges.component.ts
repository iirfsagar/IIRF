import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { TopEngineeringCollegesService } from '../../service/top-engineering-colleges.service';
import { TopEngineeringColleges, TopPrivateEngineeringColleges} from '../../model/admisson-model';
@Component({
  selector: 'app-top-engineering-colleges',
  templateUrl: './top-engineering-colleges.component.html',
  styleUrls: ['./top-engineering-colleges.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class TopEngineeringCollegesComponent implements OnInit {

  topEngineeringColleges: TopEngineeringColleges[] = [];
  topPrivateEngineeringColleges: TopPrivateEngineeringColleges[] = [];

  panelOpenState = false;


  constructor(public _topEngineeringColleges: TopEngineeringCollegesService) {
   }

  ngOnInit(): void {
    this._topEngineeringColleges.getTopPrivateEngineeringColleges().subscribe((res)=>{
      this.topPrivateEngineeringColleges = res['2'].data; 
    })
    this._topEngineeringColleges.getTopEngineeringColleges().subscribe((res)=>{
      this.topEngineeringColleges = res['2'].data; 
    })
  }


}

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TopEngineeringCollegesComponent } from './top-engineering-colleges.component';


const routes: Routes = [
  {path: '', component: TopEngineeringCollegesComponent,
  data: {
    title: 'Top Engineering Colleges in India 2021: Rankings, Admissions, Fees, Placements and Cutoff',
    descrption: 'Ranking of top engineering colleges in India 2021: 1. IIT Delhi, 2. IIT Chennai, 3. IIT Bombay and many other Govt. Colleges. Some other good universities and private colleges in India are 1. BITS Pilani, 2. Birla Institute of Technology, 3. Manipal Institute of Technology...',
    ogTitle: 'Top Engineering Colleges in India 2021: Rankings, Admissions, Fees, Placements and Cutoff',
    keywords: 'top engineering colleges in india, top private engineering colleges in india, top 10 engineering colleges in india, top government engineering colleges in india',
  }},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TopEngineeringCollegesRoutingModule { }

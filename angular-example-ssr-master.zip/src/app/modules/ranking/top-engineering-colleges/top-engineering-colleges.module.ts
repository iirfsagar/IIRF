import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TopEngineeringCollegesComponent } from './top-engineering-colleges.component';
import { TopEngineeringCollegesRoutingModule } from './top-engineering-colleges-routing.module';
import { DataTablesModule } from "angular-datatables";
import {MatExpansionModule} from '@angular/material/expansion';

@NgModule({
  imports: [
    CommonModule,
    TopEngineeringCollegesRoutingModule,
    DataTablesModule,
    MatExpansionModule
  ], 
  exports: [
    TopEngineeringCollegesComponent  
  ],
  declarations: [
    TopEngineeringCollegesComponent
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ] 
})
export class TopEngineeringCollegesModule { } 
  
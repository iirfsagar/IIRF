import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TopSchoolsComponent } from './top-schools.component';
import { TopSchoolsRoutingModule } from './top-schools-routing.module';
import { DataTablesModule } from "angular-datatables";

@NgModule({
  imports: [
    CommonModule,
    TopSchoolsRoutingModule,
    DataTablesModule
  ], 
  exports: [
    TopSchoolsComponent  
  ],
  declarations: [
    TopSchoolsComponent
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ] 
})
export class TopSchoolsModule { } 
  
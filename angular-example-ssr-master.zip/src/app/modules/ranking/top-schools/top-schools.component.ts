import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { TopSchoolsService } from '../../service/top-schools.service';
import { SchoolofEminence, SchoolofPerformance } from '../../model/admisson-model';
@Component({
  selector: 'app-top-schools',
  templateUrl: './top-schools.component.html',
  styleUrls: ['./top-schools.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class TopSchoolsComponent implements OnInit {
  SchoolofPerformance: SchoolofPerformance[] = [];
  SchoolofEminence: SchoolofEminence[] = [];


  constructor(public _topSchoolsService: TopSchoolsService) {
   }
 
  ngOnInit(): void {
    this._topSchoolsService.getSchoolofEminence().subscribe((res)=>{
      this.SchoolofEminence = res['2'].data; 
    })
    this._topSchoolsService.getSchoolofPerformance().subscribe((res)=>{
      this.SchoolofPerformance = res['2'].data; 
    })
  }
}

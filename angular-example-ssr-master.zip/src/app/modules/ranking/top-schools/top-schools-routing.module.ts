import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TopSchoolsComponent } from './top-schools.component';


const routes: Routes = [
  {path: '', component: TopSchoolsComponent,
  data: {
    title: 'Top Schools (10+2) in India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    descrption: "List of Top 10, 20, 50 and 100 Schools (10+2) in India 2021: 1. St. Xavier's Senior Secondary School, Raj Niwas Marg, 2. Delhi Public School, R K Puram, 3. The Valley School, 4. Vidyashilp Academy",
    ogTitle: 'Top Schools (10+2) in India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    keywords: 'top schools in india, top 10 schools in india, top boarding schools in india, schools ranking 2021',
  }},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TopSchoolsRoutingModule { }

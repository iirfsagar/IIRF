import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { ArchitectureCollegesService } from '../../service/architecture-colleges.service';
import { ArchitectureCollegesPvt, ArchitectureCollegesGovt } from '../../model/admisson-model';
@Component({
  selector: 'app-architecture-colleges',
  templateUrl: './architecture-colleges.component.html',
  styleUrls: ['./architecture-colleges.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class ArchitectureCollegesComponent implements OnInit {

  architectureCollegesPvt: ArchitectureCollegesPvt[] = [];
  architectureCollegesGovt: ArchitectureCollegesGovt[] = [];


  constructor(public _architectureColleges: ArchitectureCollegesService) {
   }
 
  ngOnInit(): void {
    this._architectureColleges.getArchitectureCollegesPvt().subscribe((res)=>{
      this.architectureCollegesPvt = res['2'].data; 
    })
    this._architectureColleges.getArchitectureCollegesGovt().subscribe((res)=>{
      this.architectureCollegesGovt = res['2'].data; 
    })
  }
 

}

import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ArchitectureCollegesComponent } from './architecture-colleges.component';
import { ArchitectureCollegesRoutingModule } from './architecture-colleges-routing.module';
import { DataTablesModule } from "angular-datatables";

@NgModule({
  imports: [
    CommonModule,
    ArchitectureCollegesRoutingModule,
    DataTablesModule
  ], 
  exports: [
    ArchitectureCollegesComponent  
  ],
  declarations: [
    ArchitectureCollegesComponent
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ] 
})
export class ArchitectureCollegesModule { } 
  
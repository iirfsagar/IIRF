import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ArchitectureCollegesComponent } from './architecture-colleges.component';


const routes: Routes = [
  {path: '', component: ArchitectureCollegesComponent,
  data: {
    title: 'Top Architecture Colleges in India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    descrption: 'Architecture Ranking 2021 helps you to decide which Architecture College you should apply to on the best available options. List of Top Architecture Colleges (Private) in India 2021: 1. Birla Institute of Technology, 2. Manipal Academy of Higher Education, 3. L S Raheja School of Architecture, Rizvi College of Architecture',
    ogTitle: 'Top Architecture Colleges in India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    keywords: 'top architecture colleges in india, top 10 architecture colleges, best architecture colleges, top 50 architecture colleges in india, top private architecture colleges in india',
  }},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ArchitectureCollegesRoutingModule { }

import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TopUniversitiesComponent } from '../top-universities/top-universities-un/top-universities.component';
import { TopUniversitiesRoutingModule } from './top-universities-routing.module';
import {MatExpansionModule} from '@angular/material/expansion';
import { DataTablesModule } from "angular-datatables";
import { AdduniversitiesComponent } from './adduniversities/adduniversities.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
@NgModule({
  imports: [   
    CommonModule,
    TopUniversitiesRoutingModule,
    MatExpansionModule,
    DataTablesModule,
    FormsModule
  ], 

  exports: [
    TopUniversitiesComponent,
    AdduniversitiesComponent,
  ],
  declarations: [ 
    TopUniversitiesComponent,
    AdduniversitiesComponent,
  ],  
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]  
})
export class TopUniversitiesModule { }    
  
import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { AngularEditorConfig } from '@kolkov/angular-editor'; 
import { TopPrivateUniversitiesService } from '../../../service/top-private-universities.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-adduniversities',
  templateUrl: './adduniversities.component.html',
  styleUrls: ['./adduniversities.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class AdduniversitiesComponent implements OnInit {
  constructor(public addUn: TopPrivateUniversitiesService) { }
 
  ngOnInit(): void {
  }
  onAddPost(form: NgForm){
    if(form.invalid){
      return;
      console.log('Hello')
    }
    this.addUn.addTopDeemedUniversities(form.value.rank, form.value.nameofinstitutes, form.value.city, form.value.state, form.value.content, form.value.address, form.value.img);
  }
  editorConfig: AngularEditorConfig = {
    editable: true,
      spellcheck: true,
      height: '300px',
      minHeight: '500',
      maxHeight: 'auto',
      width: 'auto',
      minWidth: '0',
      translate: 'yes',
      enableToolbar: true,
      showToolbar: true,
      placeholder: 'Enter text here...',
      defaultParagraphSeparator: '',
      defaultFontName: '',
      defaultFontSize: '',
      fonts: [
        {class: 'arial', name: 'Arial'},
        {class: 'times-new-roman', name: 'Times New Roman'},
        {class: 'calibri', name: 'Calibri'},
        {class: 'comic-sans-ms', name: 'Comic Sans MS'}
      ],
      customClasses: [
      {
        name: 'quote',
        class: 'quote',
      },
      {
        name: 'redText',
        class: 'redText'
      },
      {
        name: 'titleText',
        class: 'titleText',
        tag: 'h1',
      },
    ],
    uploadUrl: 'v1/image',
    uploadWithCredentials: false,
    sanitize: true,
    toolbarPosition: 'top',
    toolbarHiddenButtons: [
      // ['bold', 'italic'],
      // ['fontSize']
    ]
};

}

import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { TopPrivateUniversitiesService } from '../../../service/top-private-universities.service';
import { TopPrivateUniversities , TopPrivateUniversitiesEmerging, TopDeemedUniversities} from '../../../model/admisson-model';
@Component({
  selector: 'app-top-universities',
  templateUrl: './top-universities.component.html',
  styleUrls: ['./top-universities.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class TopUniversitiesComponent implements OnInit {
  
  panelOpenState = false;
  
  TopPrivateUniversities: TopPrivateUniversities[] = [];
  TopPrivateUniversitiesEmerging: TopPrivateUniversitiesEmerging[] = [];
  TopDeemedUniversities: TopDeemedUniversities[] = [];

  constructor(public _topPrivateUniversities: TopPrivateUniversitiesService) {

   }

  ngOnInit(): void {
    this._topPrivateUniversities.getTopDeemedUniversities().subscribe((res)=>{
      this.TopDeemedUniversities = res['2'].data; 
    })
    this._topPrivateUniversities.getTopPrivateUniversities().subscribe((res)=>{
      this.TopPrivateUniversities = res['2'].data; 
    })
    this._topPrivateUniversities.getTopPrivateUniversitiesEmerging().subscribe((res)=>{
      this.TopPrivateUniversitiesEmerging = res['2'].data; 
    })
  }

}

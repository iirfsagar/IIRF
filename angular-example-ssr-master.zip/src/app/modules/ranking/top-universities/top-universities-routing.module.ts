import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TopUniversitiesComponent } from '../top-universities/top-universities-un/top-universities.component';



const routes: Routes = [
  {path: '', component: TopUniversitiesComponent,
  data: {
    title: 'Top Universities in India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    descrption: 'Ranking of Top Universities in India 2021: 1. IISc, Bangalore, 2. Homi Bhabha National Institute, 3. Indira Gandhi Institute of Development Research and many others. Some other good universities and private colleges in India are 1. O.P. Jindal Global University, 2. Shiv Nadar University, 3. DAIICT Gandhinagar',
    ogTitle: 'Top Universities in India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    keywords: 'top university in india, best universities in india, top 10 university in india, top private university in india, top government university in india, top central university in india',
  }},

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TopUniversitiesRoutingModule { } 

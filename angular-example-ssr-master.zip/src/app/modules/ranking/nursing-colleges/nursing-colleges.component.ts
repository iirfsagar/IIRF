import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nursing-colleges',
  templateUrl: './nursing-colleges.component.html',
  styleUrls: ['./nursing-colleges.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class NursingCollegesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NursingCollegesComponent } from './nursing-colleges.component';


const routes: Routes = [
  {path: '', component: NursingCollegesComponent,
  data: {
    title: 'Top Nursing Colleges in India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    descrption: 'View Top Nursing Colleges in India 2021. See list of Top 10, 20, 50 & 100 Top Nursing Colleges in India by IIRF. Check Ranking, Admission, Placement, Fees, Cutoffs and Eligibility of Nursing Colleges for 2021.',
    ogTitle: 'Top Nursing Colleges in India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    keywords: 'top nursing colleges in india, top bsc nursing colleges in india, top 10 nursing colleges in india, top msc nursing colleges in india',
  }},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class NursingCollegesRoutingModule { }

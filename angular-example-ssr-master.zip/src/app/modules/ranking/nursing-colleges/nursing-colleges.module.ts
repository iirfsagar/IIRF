import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NursingCollegesComponent } from './nursing-colleges.component';
import { NursingCollegesRoutingModule } from './nursing-colleges-routing.module';
import { DataTablesModule } from "angular-datatables";

@NgModule({
  imports: [
    CommonModule,
    NursingCollegesRoutingModule,
    DataTablesModule
  ], 
  exports: [
    NursingCollegesComponent  
  ],
  declarations: [
    NursingCollegesComponent
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ] 
})
export class NursingCollegesModule { } 
  
import { Component } from '@angular/core';

@Component({
  selector: 'app-ranking',
  templateUrl: './app.ranking.html',
  styleUrls: ['./app.ranking.scss']
})
export class AppRankings {
  // title = 'iirfranking';
}
 
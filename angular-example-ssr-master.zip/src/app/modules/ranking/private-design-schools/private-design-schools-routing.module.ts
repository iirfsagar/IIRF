import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PrivateDesignSchoolsComponent } from './private-design-schools.component';


const routes: Routes = [
  {path: '', component: PrivateDesignSchoolsComponent,
  data: {
    title: 'Top Design Schools/ Colleges in India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    descrption: 'IIRF Design Ranking 2021 helps you decide which Design School/ College you should apply to with the best available options. Top Design Schools/ Colleges(Private) in India 2021 are  1. UID, Gandhinagar. 2. Pearl Academy, Delhi. 3. Pearl Academy, Mumbai',
    ogTitle: 'Top Design Schools/ Colleges in India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    keywords: 'top design colleges in india, top design schools in india, top 100 design schools, top 10 design colleges, best private design school, top interior design govt colleges in india',
  }},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PrivateDesignSchoolsRoutingModule { }

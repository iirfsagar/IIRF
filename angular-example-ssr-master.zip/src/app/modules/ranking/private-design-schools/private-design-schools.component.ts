import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { DesignschoolsService } from '../../service/designschools.service';
import {DesignSchoolsPvt, DesignSchoolsGovt } from '../../model/admisson-model';

@Component({
  selector: 'app-private-design-schools',
  templateUrl: './private-design-schools.component.html',
  styleUrls: ['./private-design-schools.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class PrivateDesignSchoolsComponent implements OnInit {

  designSchoolPvt: DesignSchoolsPvt[] = [];
  designSchoolGovt: DesignSchoolsGovt[] = [];


  constructor(public _designschools: DesignschoolsService) {
   }
 
  ngOnInit(): void {
    this._designschools.getDesignSchoolsGovt().subscribe((res)=>{
      this.designSchoolGovt = res['2'].data; 
    })
    this._designschools.getDesignSchoolsPvt().subscribe((res)=>{
      this.designSchoolPvt = res['2'].data; 
    })
  }


}

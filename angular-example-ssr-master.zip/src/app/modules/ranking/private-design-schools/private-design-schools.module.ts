import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PrivateDesignSchoolsComponent } from './private-design-schools.component';
import { PrivateDesignSchoolsRoutingModule } from './private-design-schools-routing.module';
import { DataTablesModule } from "angular-datatables";

@NgModule({
  imports: [
    CommonModule,
    PrivateDesignSchoolsRoutingModule,
    DataTablesModule
  ], 
  exports: [
    PrivateDesignSchoolsComponent  
  ],
  declarations: [
    PrivateDesignSchoolsComponent
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ] 
})
export class PrivateDesignSchoolsModule { } 
  
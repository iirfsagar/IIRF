import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HealthCollegesComponent } from './health-colleges.component';
import { HealthCollegesRoutingModule } from './health-colleges-routing.module';
import { DataTablesModule } from "angular-datatables";

@NgModule({
  imports: [
    CommonModule,
    HealthCollegesRoutingModule,
    DataTablesModule
  ], 
  exports: [
    HealthCollegesComponent  
  ],
  declarations: [
    HealthCollegesComponent
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ] 
})
export class HealthCollegesModule { } 
  
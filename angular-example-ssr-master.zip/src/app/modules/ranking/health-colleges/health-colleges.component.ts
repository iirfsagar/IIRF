import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-health-colleges',
  templateUrl: './health-colleges.component.html',
  styleUrls: ['./health-colleges.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class HealthCollegesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

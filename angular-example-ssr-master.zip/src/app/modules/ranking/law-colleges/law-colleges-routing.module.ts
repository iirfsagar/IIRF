import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LawCollegesComponent } from './law-colleges.component';


const routes: Routes = [
  {path: '', component: LawCollegesComponent,
  data: {
    title: 'Top Law Colleges in India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    descrption: 'Law Colleges Ranking 2021 helps you to decide which Law College you should apply to on the best available options. List of Top 10, 20, 50 & 100 Law Colleges (Private) in India 2021: 1. Bharati Vidyapeeth, 2. Symbiosis Law School, 3. ARMY Institute of Law, 4. Jindal Global Law School, 5. ICFAI Law School',
    ogTitle: 'Top Law Colleges in India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    keywords: 'top law colleges in india, top 10 law colleges in india, top private law colleges in india, top govt law colleges in india, list of top law colleges in india',
  }},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LawCollegesRoutingModule { }

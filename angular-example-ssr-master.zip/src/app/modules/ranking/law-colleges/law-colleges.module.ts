import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LawCollegesComponent } from './law-colleges.component';
import { LawCollegesRoutingModule } from './law-colleges-routing.module';
import { DataTablesModule } from "angular-datatables";

@NgModule({
  imports: [
    CommonModule,
    LawCollegesRoutingModule,
    DataTablesModule
  ], 
  exports: [
    LawCollegesComponent  
  ],
  declarations: [
    LawCollegesComponent
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ] 
})
export class LawCollegesModule { } 
  
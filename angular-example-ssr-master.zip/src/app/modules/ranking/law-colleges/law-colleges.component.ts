import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { LowCollegesService } from '../../service/law-colleges.service';
import { LawCollegesPvt, LawCollegesGovt } from '../../model/admisson-model';
@Component({
  selector: 'app-law-colleges',
  templateUrl: './law-colleges.component.html',
  styleUrls: ['./law-colleges.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class LawCollegesComponent implements OnInit {

  lawCollegesGovt: LawCollegesGovt[] = [];

  lawCollegesPvt: LawCollegesPvt[] = [];



  constructor(public _lowCollegesService: LowCollegesService) {
   }
  
  ngOnInit(): void {
    
    this._lowCollegesService.getLawCollegesGovt().subscribe((res)=>{
      this.lawCollegesGovt = res['2'].data;  
    })

    this._lowCollegesService.getLawCollegesPvt().subscribe((res)=>{
      this.lawCollegesPvt = res['2'].data; 
    })
  }
 


}

import { NgModule , CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { CommonModule } from '@angular/common'; 
import {MatExpansionModule} from '@angular/material/expansion';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRankings } from './app.ranking';
import { RankingsRoutingModule } from './rankings-routing.module';



@NgModule({  

  imports: [ 
    CommonModule,
    MatExpansionModule,
    FormsModule,
    HttpClientModule,
    RankingsRoutingModule

  ],
  declarations: [ 
    AppRankings,  

  ],
  exports: [     
    AppRankings,

  ], 
  bootstrap: [],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class RankingsModule { }

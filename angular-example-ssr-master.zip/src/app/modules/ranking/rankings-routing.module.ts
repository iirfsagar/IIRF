import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdduniversitiesComponent } from './top-universities/adduniversities/adduniversities.component';
import { AppRankings } from './app.ranking';
import { UniversityDetailsPageComponent } from './university-details-page/university-details-page.component';
 
 

const routes: Routes = [

  // {path: 'add-mbaranking', component: AddmbarankingComponent}, 
  // {path: 'ranking/top-architecture-colleges-in-india', component: ArchitectureCollegesComponent,
  // data: {
  //   title: 'Top MBA Colleges/ Best B-School in East, India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
  //   descrption: 'IIRF MBA Rankings 2021 help you to decide which MBA College/ B School you should apply on the best available options. The Top MBA Colleges/ B-School Rankings in East, India 2021 are 1. XLRI, 2. Xavier Institute Of Management, 3. Indian Institute Of Management...',
  //   ogTitle: 'Top MBA Colleges/ Best B-School in East, India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
  // }}, 




 

{
  path: '', component: AppRankings, children: [
    {
      path: 'top-architecture-colleges-in-india',
      loadChildren: () => import('./architecture-colleges/architecture-colleges.module')
        .then(m => m.ArchitectureCollegesModule)
    },
    {
      path: 'top-design-schools-in-india',
      loadChildren: () => import('./private-design-schools/private-design-schools.module')
        .then(m => m.PrivateDesignSchoolsModule)
    },
    {
      path: 'top-law-colleges-in-india',
      loadChildren: () => import('./law-colleges/law-colleges.module')
        .then(m => m.LawCollegesModule)
    },
    {
      path: 'top-schools-in-india',
      loadChildren: () => import('./top-schools/top-schools.module')
        .then(m => m.TopSchoolsModule)
    },
    {
      path: 'top-mbbs-colleges-in-india',
      loadChildren: () => import('./mbbs-colleges/mbbs-colleges.module')
        .then(m => m.MbbsCollegesModule)
    },
    {
      path: 'top-pharmacy-colleges-in-india',
      loadChildren: () => import('./pharmacy-colleges/pharmacy-colleges.module')
        .then(m => m.PharmacyCollegesModule)
    },
    {
      path: 'top-public-health-colleges-in-india',
      loadChildren: () => import('./health-colleges/health-colleges.module')
        .then(m => m.HealthCollegesModule)
    },
    {
      path: 'the-top-nursing-colleges-in-india',
      loadChildren: () => import('./nursing-colleges/nursing-colleges.module')
        .then(m => m.NursingCollegesModule)
    },
    {
      path: 'top-dental-colleges-in-india',
      loadChildren: () => import('./dental-colleges/dental-colleges.module')
        .then(m => m.DentalCollegesModule)
    },
    {
      path: 'top-engineering-colleges-in-india',
      loadChildren: () => import('./top-engineering-colleges/top-engineering-colleges.module')
        .then(m => m.TopEngineeringCollegesModule)
    },
    {
      path: 'top-universities-in-india',
      loadChildren: () => import('./top-universities/top-universities.module')
        .then(m => m.TopUniversitiesModule)
    },
    {path: 'top-universities-in-india/:id', component: UniversityDetailsPageComponent,
    data: {
      title: 'Top MBA Colleges/ Best B-School in East, India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
      descrption: 'IIRF MBA Rankings 2021 help you to decide which MBA College/ B School you should apply on the best available options. The Top MBA Colleges/ B-School Rankings in East, India 2021 are 1. XLRI, 2. Xavier Institute Of Management, 3. Indian Institute Of Management...',
      ogTitle: 'Top MBA Colleges/ Best B-School in East, India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    }},
  ]
},
];  

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RankingsRoutingModule { }

import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DentalCollegesComponent } from './dental-colleges.component';
import { DentalCollegesRoutingModule } from './dental-colleges-routing.module';
import { DataTablesModule } from "angular-datatables";

@NgModule({
  imports: [
    CommonModule,
    DentalCollegesRoutingModule,
    DataTablesModule
  ], 
  exports: [
    DentalCollegesComponent  
  ],
  declarations: [
    DentalCollegesComponent
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ] 
})
export class DentalCollegesModule { } 
  
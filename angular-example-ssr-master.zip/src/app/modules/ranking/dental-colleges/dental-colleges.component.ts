import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dental-colleges',
  templateUrl: './dental-colleges.component.html',
  styleUrls: ['./dental-colleges.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class DentalCollegesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

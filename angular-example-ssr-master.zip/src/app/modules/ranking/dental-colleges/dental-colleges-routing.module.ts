import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DentalCollegesComponent } from './dental-colleges.component';


const routes: Routes = [
  {path: '', component: DentalCollegesComponent,
  data: {
    title: 'Top Dental Colleges In India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    descrption: 'View Top Dental Colleges In India 2021. See list of Top 10, 20, 50 & 100 Top Dental Colleges In India by IIRF. Check Ranking, Admission, Placement, Fees, Cutoffs and Eligibility of Dental Colleges for 2021.',
    ogTitle: 'Top Dental Colleges In India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    keywords: 'top dental colleges in india, top 50 dental colleges in india, top 10 private dental colleges in india, top government dental colleges in india',
  }},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DentalCollegesRoutingModule { }

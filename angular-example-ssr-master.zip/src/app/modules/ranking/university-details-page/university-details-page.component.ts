import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { TopPrivateUniversitiesService } from '../../service/top-private-universities.service';
   
@Component({
  selector: 'app-university-details-page',
  templateUrl: './university-details-page.component.html',
  styleUrls: ['./university-details-page.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class UniversityDetailsPageComponent implements OnInit {      

  content_id: any = '';
  admissionData: any = [];

  constructor(private activatRoute: ActivatedRoute,  private http: HttpClient, public _topPrivateUniversities: TopPrivateUniversitiesService) {
    
   }
 
  ngOnInit(): void {
    this.content_id = this.activatRoute.snapshot.params['id']

    this._topPrivateUniversities.getTopDeemedUniversitiesId(this.content_id).subscribe((res) => {
      this.admissionData = res['data'].doc; 
      // console.log(res)
    })
  }


}

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PharmacyCollegesComponent } from './pharmacy-colleges.component';


const routes: Routes = [
  {path: '', component: PharmacyCollegesComponent,
  data: {
    title: 'Top Pharmacy Colleges in India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    descrption: 'View Top Pharmacy Colleges in India 2021. See list of Top 10, 20, 50 & 100 Top Pharmacy Colleges in India 2021 by IIRF. Check Ranking, Admission, Placement, Fees, Cutoffs and Eligibility of Pharmacy Colleges for 2021.',
    ogTitle: 'Top Pharmacy Colleges in India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    keywords: 'top pharmacy colleges in india, top 10 pharmacy colleges in india, top m pharmacy colleges in india, top b pharmacy colleges in india, top pharmacy colleges in india rank wise',
  }},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PharmacyCollegesRoutingModule { }

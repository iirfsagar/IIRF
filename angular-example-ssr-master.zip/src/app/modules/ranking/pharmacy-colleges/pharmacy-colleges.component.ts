import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pharmacy-colleges',
  templateUrl: './pharmacy-colleges.component.html',
  styleUrls: ['./pharmacy-colleges.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class PharmacyCollegesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

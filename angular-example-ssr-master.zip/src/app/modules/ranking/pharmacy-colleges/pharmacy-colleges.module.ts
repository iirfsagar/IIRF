import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PharmacyCollegesComponent } from './pharmacy-colleges.component';
import { PharmacyCollegesRoutingModule } from './pharmacy-colleges-routing.module';
import { DataTablesModule } from "angular-datatables";

@NgModule({
  imports: [
    CommonModule,
    PharmacyCollegesRoutingModule,
    DataTablesModule
  ], 
  exports: [
    PharmacyCollegesComponent  
  ],
  declarations: [
    PharmacyCollegesComponent
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ] 
})
export class PharmacyCollegesModule { } 
  
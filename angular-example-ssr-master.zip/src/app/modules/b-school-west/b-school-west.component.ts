import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { BSchoolWestService } from '../service/b-school-west.service';
import { bSchoolWestScores, bSchoolWestRanking} from '../model/admisson-model';
@Component({
  selector: 'app-b-school-west',
  templateUrl: './b-school-west.component.html',
  styleUrls: ['./b-school-west.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class BSchoolWestComponent implements OnInit {

  bSchoolWestRanking: bSchoolWestRanking[] = [];
  bSchoolWestScores: bSchoolWestScores[] = [];
  constructor(public bSchoolWest: BSchoolWestService) {
   }

  ngOnInit(): void {
    this.bSchoolWest.getbSchoolRanking().subscribe((res)=>{
      this.bSchoolWestRanking = res['2'].data; 
    })
    this.bSchoolWest.getbSchoolScores().subscribe((res)=>{
      this.bSchoolWestScores = res['2'].data; 
    })
  }
}

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BSchoolWestComponent } from './b-school-west.component';


const routes: Routes = [
  {path: '', component: BSchoolWestComponent,
  data: {
    title: 'Top MBA Colleges/ Best B-School in West, India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    descrption: 'IIRF MBA Ranking 2021 helps you to decide which MBA College/ B School you should apply to on the best available options. List of Top MBA Colleges/ B-School in West, India 2021: 1. SPJIMR, 2. SCMHRD, 3.MICA, 4. Symbiosis Institute Of Business Management...',
    ogTitle: 'Top MBA Colleges/ Best B-School in West, India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    keywords: 'top mba colleges in west india, top b schools in west india, top 100 mba colleges in west india, top 10 mba colleges in west india, top colleges for mba in west india, top private b schools in west india',
  }},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BSchoolWestRoutingModule { }

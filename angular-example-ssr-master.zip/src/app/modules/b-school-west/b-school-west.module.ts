import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BSchoolWestComponent } from './b-school-west.component';
import { BSchoolWestRoutingModule } from './b-school-west-routing.module';
import { DataTablesModule } from "angular-datatables";

@NgModule({
  imports: [
    CommonModule,
    BSchoolWestRoutingModule,
    DataTablesModule
  ], 
  exports: [
    BSchoolWestComponent  
  ],
  declarations: [
    BSchoolWestComponent
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ] 
})
export class BSchoolWestModule { } 
  
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutUsComponent } from './about-us/about-us.component';

const routes: Routes = [
  {path: '', component: AboutUsComponent,
  data: {
    title: 'About Us: IIRF Ranking by Industry-Academia Professionals',
    descrption: 'IIRF is presented and published by EDUCATION POST, a monthly magazine on higher education since 2012. FEDERATION FOR WORLD ACADEMICS (FWA) guides the methodology and industrial feedback and plays the role of Mentor for IIRF Centre for Institutional Research (ICIR) in India. ',
    ogTitle: 'About Us: IIRF Ranking by Industry-Academia Professionals',
  } 
},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AboutRoutingModule { }

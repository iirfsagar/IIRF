import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BSchoolEastComponent } from './b-school-east.component';


const routes: Routes = [
  {path: '', component: BSchoolEastComponent,
  data: {
    title: 'Top MBA Colleges/ Best B-School in East, India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    descrption: 'IIRF MBA Ranking 2021 helps you to decide which MBA College/ B School you should apply to on the best available options. List of  Top MBA Colleges/ B-Schools in East, India 2021: 1. XLRI, 2. Xavier Institute Of Management, 3. Indian Institute Of Management...',
    ogTitle: 'Top MBA Colleges/ Best B-School in East, India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    keywords: 'top mba colleges in east india, top b schools in east india, top 100 mba colleges in east india, top 10 mba colleges in east india, top colleges for mba in east india, top private b schools in east india',
  }},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BSchoolEastRoutingModule { }

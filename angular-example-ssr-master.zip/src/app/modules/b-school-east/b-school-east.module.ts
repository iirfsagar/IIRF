import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BSchoolEastComponent } from './b-school-east.component';
import { BSchoolEastRoutingModule } from './b-school-east-routing.module';
import { DataTablesModule } from "angular-datatables";
@NgModule({
  imports: [
    CommonModule,
    BSchoolEastRoutingModule,
    DataTablesModule
  ], 
  exports: [
    BSchoolEastComponent  
  ],
  declarations: [
    BSchoolEastComponent
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ] 
})
export class BSchoolEastgModule { } 
  
import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { BSchoolEastService } from '../service/b-school-east.service';
import { bSchoolEastRanking, bSchoolWestScores} from '../model/admisson-model';
@Component({
  selector: 'app-b-school-east',
  templateUrl: './b-school-east.component.html',
  styleUrls: ['./b-school-east.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class BSchoolEastComponent implements OnInit {

  bSchoolEastRanking: bSchoolEastRanking[] = [];
  bSchoolEastScores: bSchoolWestScores[] = [];
  constructor(public bSchoolEast: BSchoolEastService) {
   }

  ngOnInit(): void {
    this.bSchoolEast.getbSchoolRanking().subscribe((res)=>{
      this.bSchoolEastRanking = res['2'].data; 
    })
    this.bSchoolEast.getbSchoolScores().subscribe((res)=>{
      this.bSchoolEastScores = res['2'].data; 
    })
  }

}

import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BSchoolSouthComponent } from './b-school-south.component';
import { BSchoolSouthRoutingModule } from './b-school-south-routing.module';
import { DataTablesModule } from "angular-datatables";

@NgModule({
  imports: [
    CommonModule,
    BSchoolSouthRoutingModule,
    DataTablesModule
  ], 
  exports: [
    BSchoolSouthComponent  
  ],
  declarations: [
    BSchoolSouthComponent
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ] 
})
export class BSchoolSouthModule { } 
  
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BSchoolSouthComponent } from './b-school-south.component';


const routes: Routes = [
  {path: '', component: BSchoolSouthComponent,
  data: {
    title: 'Top MBA Colleges/ Best B-School in South, India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    descrption: 'IIRF MBA Ranking 2021 helps you to decide which MBA College/ B School you should apply to on the best available options. List of Top MBA Colleges/ B-School in South, India 2021: 1.Indian School of Business, 2. Great Lakes Institute of Management, 3. WOXSEN School of Business, 4. T.A.PAI Management Institute...',
    ogTitle: 'Top MBA Colleges/ Best B-School in South, India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    keywords: 'top mba colleges in south india, top b schools in south india, top 100 mba colleges in south india, top 10 mba colleges in south india, top colleges for mba in south india, top private b schools in south.',
  }},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BSchoolSouthRoutingModule { }

import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { BSchoolSouthService } from '../service/b-school-south.service';
import { bSchoolSouthScores , bSchoolSouthRanking} from '../model/admisson-model';
@Component({
  selector: 'app-b-school-south',
  templateUrl: './b-school-south.component.html',
  styleUrls: ['./b-school-south.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class BSchoolSouthComponent implements OnInit {

  bSchoolSouthRanking: bSchoolSouthRanking[] = [];
  bSchoolSouthScores: bSchoolSouthScores[] = [];
  constructor(public bSchoolSouth: BSchoolSouthService) {
   }

  ngOnInit(): void {
    this.bSchoolSouth.getbSchoolRanking().subscribe((res)=>{
      this.bSchoolSouthRanking = res['2'].data; 
    })
    this.bSchoolSouth.getbSchoolScores().subscribe((res)=>{
      this.bSchoolSouthScores = res['2'].data; 
    })
  }
}

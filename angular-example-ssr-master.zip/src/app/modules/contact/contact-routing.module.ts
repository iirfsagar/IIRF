import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContactUsComponent } from './contact-us/contact-us.component';


const routes: Routes = [
    {path: '', component: ContactUsComponent,
  data: {
    title: 'Contact Us for Help & Higher Education Guidance - IIRF Ranking',
    descrption: 'IIRF Ranking is here to help You. Discover our office location & Guidance on Higher Education, Admissions, Courses, Exams and much more on iirfranking.com',
    ogTitle: 'Contact Us for Help & Higher Education Guidance - IIRF Ranking',
    keywords: 'contact us,discover, office location, guidance higher education, admissions, courses, exams,',
  }
},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ContactRoutingModule { }

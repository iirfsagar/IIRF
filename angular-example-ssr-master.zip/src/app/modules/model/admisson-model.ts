export interface Admission{
    id: any;
    title: string;
    img: string;
    shottitle: string;
    content: string;
  }
  export interface MbaRanking{
    id: any;
    img: string;
    rank: string;
    businessschools: string;
    weightedindex: string;
    placementperformance: string;
    tlrp: string;
    research: string;
    industryincomeintegration: string;
    pss: string;
    futureorientation: string;
    epio: string;
    address: string;
    iirfranking: string;
    content: string;
  }

  export interface EminenceRanking{
    id: any;
    rank: string;
    businessschools: string;
    weightedindex: string;
  }

  export interface EminenceScores{
    id: any;
    rank: string;
    businessschools: string;
    placementperformance: string;
    tlrp: string;
    research: string;
    industryincomeintegration: string;
    pss: string;
    futureorientation: string;
    epio: string;
  }

  export interface bSchoolsRanking{
    id: any;
    rank: string;
    businessschools: string;
    weightedindex: string;
  }

  export interface bSchoolsScores{
    id: any;
    rank: string;
    businessschools: string;
    placementperformance: string;
    tlrp: string;
    research: string;
    industryincomeintegration: string;
    pss: string;
    futureorientation: string;
    epio: string;
  }

  export interface bSchoolNorthRanking{
    id: any;
    rank: string;
    businessschools: string;
    weightedindex: string;
  }

  export interface bSchoolNorthScores{
    id: any;
    rank: string;
    businessschools: string;
    placementperformance: string;
    tlrp: string;
    research: string;
    industryincomeintegration: string;
    pss: string;
    futureorientation: string;
    epio: string;
  }


  export interface bSchoolSouthRanking{
    id: any;
    rank: string;
    businessschools: string;
    weightedindex: string;
  }

  export interface bSchoolSouthScores{
    id: any;
    rank: string;
    businessschools: string;
    placementperformance: string;
    tlrp: string;
    research: string;
    industryincomeintegration: string;
    pss: string;
    futureorientation: string;
    epio: string;
  }


  export interface bSchoolCentralRanking{
    id: any;
    rank: string;
    businessschools: string;
    weightedindex: string;
  }

  
  export interface bSchoolCentralScores{
    id: any;
    rank: string;
    businessschools: string;
    placementperformance: string;
    tlrp: string;
    research: string;
    industryincomeintegration: string;
    pss: string;
    futureorientation: string;
    epio: string;
  }

  export interface bSchoolWestRanking{
    id: any;
    rank: string;
    businessschools: string;
    weightedindex: string;
  }

  export interface bSchoolWestScores{
    id: any;
    rank: string;
    businessschools: string;
    placementperformance: string;
    tlrp: string;
    research: string;
    industryincomeintegration: string;
    pss: string;
    futureorientation: string;
    epio: string;
  }

  export interface bSchoolEastRanking{
    id: any;
    rank: string;
    businessschools: string;
    weightedindex: string;
  }

  export interface bSchoolEastScores{
    id: any;
    rank: string;
    businessschools: string;
    placementperformance: string;
    tlrp: string;
    research: string;
    industryincomeintegration: string;
    pss: string;
    futureorientation: string;
    epio: string;
  }

  export interface DesignSchoolsPvt{
    id: any;
    rank: string;
    nameofinstitutes: string;
    city: string;
    state: string;
  } 
  export interface DesignSchoolsGovt{
    id: any;
    rank: string;
    nameofinstitutes: string;
    city: string;
    state: string;
  } 

  
  export interface ArchitectureCollegesPvt{
    id: any;
    rank: string;
    nameofinstitutes: string;
    city: string;
    state: string;
  } 
  export interface ArchitectureCollegesGovt{
    id: any;
    rank: string;
    nameofinstitutes: string;
    city: string;
    state: string;
  } 

  export interface LawCollegesPvt{
    id: any;
    rank: string;
    nameofinstitutes: string;
    city: string;
    state: string;
  } 
  export interface LawCollegesGovt{
    id: any;
    rank: string;
    nameofinstitutes: string;
    city: string;
    state: string;
  } 


  export interface SchoolofPerformance{
    id: any;
    rank: string;
    nameofinstitutes: string;
    city: string;
    state: string;
  } 
  export interface SchoolofEminence{
    id: any;
    rank: string;
    nameofinstitutes: string;
    city: string;
    state: string;
  } 

  export interface TopEngineeringColleges{
    id: any;
    rank: string;
    nameofinstitutes: string;
    status: string;
    city: string;
    nationalprivatecategoryrank: string;
  } 

  export interface TopPrivateEngineeringColleges{
    id: any;
    rank: string;
    nameofinstitutes: string;
    city: string;
  } 


  export interface TopPrivateUniversities{
    id: any;
    rank: string;
    nameofinstitutes: string;
    city: string;
    state: string;
  } 
  export interface TopPrivateUniversitiesEmerging{
    id: any;
    rank: string;
    nameofinstitutes: string;
    city: string;
    state: string;
  } 
  export interface TopDeemedUniversities{
    id: any;
    rank: string;
    nameofinstitutes: string;
    city: string;
    state: string;
    content: string;
    img: string;
    address: string;
  } 
  export interface WhoIsWho{
    id: any;
    img: string;
    title: string;
    subtitle: string;
    content: string;
  } 
  export interface WhoIsWhoResearch{
    id: any;
    img: string;
    title: string;
    subtitle: string;
    content: string;
  } 
  export interface WhoIsWhoEditor{
    id: any;
    img: string;
    title: string;
    subtitle: string;
    content: string;
  } 
  export interface WhoIsWhoSAARC{
    id: any;
    img: string;
    title: string;
    subtitle: string;
    content: string;
  } 

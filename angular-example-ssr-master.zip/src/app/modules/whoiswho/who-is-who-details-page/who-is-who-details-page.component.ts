import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { WhoIsWhoService } from '../../service/whoiswho.service';

@Component({
  selector: 'app-who-is-who-details-page',
  templateUrl: './who-is-who-details-page.component.html',
  styleUrls: ['./who-is-who-details-page.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class WhoIsWhoDetailsComponent implements OnInit {
  content_id: any = '';
  WhoIsWhoServiceData: any = [];

  constructor(private activatRoute: ActivatedRoute,  private http: HttpClient, public whoIsWhoService: WhoIsWhoService) {
    
   }
  ngOnInit(): void {
    this.content_id = this.activatRoute.snapshot.params['id']
    this.whoIsWhoService.getWhoIsWhoDataId(this.content_id).subscribe((res) => {
      this.WhoIsWhoServiceData = res['data'].doc;
      // console.log(res)
    })

    this.whoIsWhoService.getWhoIsWhoEditorDataId(this.content_id).subscribe((res) => {
      this.WhoIsWhoServiceData = res['data'].doc;
      // console.log(res)
    })
    this.whoIsWhoService.getWhoIsWhoResearchDataId(this.content_id).subscribe((res) => {
      this.WhoIsWhoServiceData = res['data'].doc;
      // console.log(res)
    })
    this.whoIsWhoService.getWhoIsWhoSAARCDataId(this.content_id).subscribe((res) => {
      this.WhoIsWhoServiceData = res['data'].doc;
      // console.log(res)
    })
  }

}

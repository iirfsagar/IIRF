import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WhoIsWhoRoutingModule } from './who-is-who-routing.module';
import { WhoIsWhoPageComponent } from './who-is-who-page/who-is-who-page.component';
import { WhoIsWhoDetailsComponent } from './who-is-who-details-page/who-is-who-details-page.component';


@NgModule({
  imports: [
    CommonModule,
    WhoIsWhoRoutingModule,

  ],
  declarations: [ 
    WhoIsWhoPageComponent,
    WhoIsWhoDetailsComponent
  ],
  exports: [
    WhoIsWhoPageComponent,
    WhoIsWhoDetailsComponent
  ],

})
export class WhoIsWhoModule { } 

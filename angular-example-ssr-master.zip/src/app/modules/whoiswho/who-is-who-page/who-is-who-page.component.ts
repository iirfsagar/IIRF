import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WhoIsWho , WhoIsWhoResearch , WhoIsWhoEditor, WhoIsWhoSAARC} from '../../model/admisson-model';
import { WhoIsWhoService } from '../../service/whoiswho.service';
@Component({
  selector: 'app-who-is-who-page',
  templateUrl: './who-is-who-page.component.html',
  styleUrls: ['./who-is-who-page.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class WhoIsWhoPageComponent implements OnInit {
  whoIsWho: WhoIsWho[] = [];
  WhoIsWhoresearch: WhoIsWhoResearch[] = [];
  WhoIsWhoeditor: WhoIsWhoEditor[] = [];
  WhoIsWhosAARC: WhoIsWhoSAARC[] = [];
  constructor(public whoIsWhoService: WhoIsWhoService, private http: HttpClient) {
   }

  ngOnInit(): void { 
    this.whoIsWhoService.getWhoIsWhoData().subscribe((res)=>{
      this.whoIsWho = res['2'].data; 
    })

    this.whoIsWhoService.getWhoIsWhoResearchData().subscribe((res)=>{
      this.WhoIsWhoresearch = res['2'].data; 
    })

    this.whoIsWhoService.getWhoIsWhoEditorData().subscribe((res)=>{
      this.WhoIsWhoeditor = res['2'].data; 
    })

    this.whoIsWhoService.getWhoIsWhoSAARCData().subscribe((res)=>{
      this.WhoIsWhosAARC = res['2'].data; 
    })
  }  
}

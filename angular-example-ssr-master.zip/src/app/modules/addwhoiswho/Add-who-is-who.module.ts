import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddWhoIsWhoRoutingModule } from './Add-who-is-who-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddWhoIsWhoPageComponent } from './add-page/add-page.component';
import { AngularEditorModule } from '@kolkov/angular-editor';

@NgModule({
  imports: [
    CommonModule,
    AddWhoIsWhoRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    AngularEditorModule
  ],
  declarations: [ 
    AddWhoIsWhoPageComponent
  ],
  exports: [
    AddWhoIsWhoPageComponent
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class AddWhoIsWhoModule { }

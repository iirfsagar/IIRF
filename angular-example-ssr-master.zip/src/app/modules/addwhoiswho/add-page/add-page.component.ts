import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AngularEditorConfig } from '@kolkov/angular-editor';
import { WhoIsWhoService } from '../../service/whoiswho.service'; 
 
@Component({
  selector: 'app-add-Whoiswho-page',
  templateUrl: './add-page.component.html',
  styleUrls: ['./add-page.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class AddWhoIsWhoPageComponent implements OnInit {

  constructor(public whoiswho: WhoIsWhoService) { }

  ngOnInit(): void {
  }
  onAddPost(form: NgForm){ 
    if(form.invalid){ 
      return;
      console.log('Hello') 
    }
    this.whoiswho.addWhoIsWho(  form.value.title,  form.value.content, form.value.subtitle, form.value.img );
  }
  editorConfig: AngularEditorConfig = { 
    editable: true,
      spellcheck: true,
      height: '300px',
      minHeight: '500',
      maxHeight: 'auto',
      width: 'auto',
      minWidth: '0',
      translate: 'yes',
      enableToolbar: true,
      showToolbar: true,
      placeholder: 'Enter text here...',
      defaultParagraphSeparator: '',
      defaultFontName: '',
      defaultFontSize: '',
      fonts: [
        {class: 'arial', name: 'Arial'},
        {class: 'times-new-roman', name: 'Times New Roman'},
        {class: 'calibri', name: 'Calibri'},
        {class: 'comic-sans-ms', name: 'Comic Sans MS'}
      ],
      customClasses: [
      {
        name: 'quote',
        class: 'quote',
      },
      {
        name: 'redText',
        class: 'redText'
      },
      {
        name: 'titleText',
        class: 'titleText',
        tag: 'h1',
      },
    ],
    uploadUrl: 'v1/image',
    uploadWithCredentials: false,
    sanitize: true,
    toolbarPosition: 'top',
    toolbarHiddenButtons: [
      // ['bold', 'italic'],
      // ['fontSize']
    ]
};
}

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddWhoIsWhoPageComponent } from './add-page/add-page.component';

const routes: Routes = [
      {path: '', component: AddWhoIsWhoPageComponent}, 
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AddWhoIsWhoRoutingModule { }

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataTablesModule } from "angular-datatables";

import { BschoolCenterlModuleRoutingModule } from './b-school-central-routing.module';
import { BSchoolCentralComponent } from './b-school-central.component';


@NgModule({
  imports: [
    CommonModule,
    BschoolCenterlModuleRoutingModule,
    DataTablesModule
  ],
  exports: [
    BSchoolCentralComponent
  ],
  declarations: [
    BSchoolCentralComponent
  ],
})
export class BschoolCenterlModuleModule { }

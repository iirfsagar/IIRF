import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BSchoolCentralComponent } from './b-school-central.component';


const routes: Routes = [
  {path: '', component: BSchoolCentralComponent,
  data: {
    title: 'Top MBA Colleges/ Best B-School in Central, India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    descrption: 'IIRF MBA Ranking 2021 helps you to decide which MBA College/ B School you should apply to on the best available options. List of Top MBA Colleges/ B-School Rankings in Central, India 2021: 1. Prestige Institute Of Management And Research, 2. Indore Management Institute, 3. ITM University Gwalior...',
    ogTitle: 'Top MBA Colleges/ Best B-School in Central, India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    keywords: 'top mba colleges in central india, top b schools in central india, top 100 mba colleges in central india, top 10 mba colleges in central india, top colleges for mba in central india, top private b schools in central india',
  }},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BschoolCenterlModuleRoutingModule { }

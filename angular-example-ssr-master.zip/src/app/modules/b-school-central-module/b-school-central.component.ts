import { Component, OnInit } from '@angular/core';
import { BSchoolCentralService } from '../service/b-school-central.service';
import { bSchoolCentralRanking, bSchoolCentralScores } from '../model/admisson-model';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Subject } from 'rxjs';


@Component({
  selector: 'app-b-school-central',
  templateUrl: './b-school-central.component.html',
  styleUrls: ['./b-school-central.component.scss'],
})


export class BSchoolCentralComponent implements OnInit {


  bschoolCentralRanking: bSchoolCentralRanking[] = [];
  bschoolCentralScores: bSchoolCentralScores[] = [];


  constructor(public bSchoolCentral: BSchoolCentralService, private http: HttpClient) {

   }


   ngOnInit(): void {
    this.bSchoolCentral.getbSchoolRanking().subscribe((res)=>{
      this.bschoolCentralRanking = res['2'].data; 
      console.log(res)
    })
    this.bSchoolCentral.getbSchoolScores().subscribe((res)=>{
      this.bschoolCentralScores = res['2'].data; 
    })
  }
}




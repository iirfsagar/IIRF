import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TopPrivateBSchoolsRoutingModule } from './top-private-b-schools-routing.module';
import { TopPrivateBSchoolsComponent } from './top-private-b-schools.component';
import { DataTablesModule } from "angular-datatables";

@NgModule({
  imports: [
    CommonModule,
    TopPrivateBSchoolsRoutingModule,
    DataTablesModule
  ],
  exports: [
    TopPrivateBSchoolsComponent
  ],
  declarations: [
    TopPrivateBSchoolsComponent
  ],
})
export class TopPrivateBSchoolsModule { }

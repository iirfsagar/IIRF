import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { BSchoolService } from '../service/b-school.service';
import { bSchoolsRanking , bSchoolsScores } from '../model/admisson-model';
@Component({
  selector: 'app-top-private-b-schools',
  templateUrl: './top-private-b-schools.component.html',
  styleUrls: ['./top-private-b-schools.component.scss'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class TopPrivateBSchoolsComponent implements OnInit {
  BSchoolRanking: bSchoolsRanking[] = [];
  BSchoolScores: bSchoolsScores[] = [];

  constructor(public bSchool: BSchoolService) { 
  }

  ngOnInit(): void {
    this.bSchool.getbSchoolRanking().subscribe((res)=>{
      this.BSchoolRanking = res['2'].data;
      // console.log(res)
    })
    this.bSchool.getbSchoolScores().subscribe((res)=>{
      this.BSchoolScores = res['2'].data;
      // console.log(res)
    })
  }
}

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TopPrivateBSchoolsComponent } from './top-private-b-schools.component';

const routes: Routes = [
  {path: '', component: TopPrivateBSchoolsComponent,
  data: {
    title: 'Top 100 MBA Colleges/ B Schools in India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    descrption: 'IIRF MBA Ranking 2021 helps you to decide which MBA College/ B School you should apply to on the best available options. List of Top 100 MBA Colleges/ B Schools in India 2021: 1. Indian School of Business, 2. Xavier Labour Relations Institute, 3. Management Development Institute, 4. S P Jain Institute of Management And Research',
    ogTitle: 'Top 100 MBA Colleges/ B Schools in India 2021: Rankings, Admissions, Fees, Placements and Cutoffs',
    keywords: 'top 100 mba colleges in india, best 100 b schools, 100 private mba colleges,list of top 100 mba colleges in india',
  }
},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TopPrivateBSchoolsRoutingModule { }

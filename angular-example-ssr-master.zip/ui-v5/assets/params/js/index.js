var navMain = document.getElementById('navbarsExampleDefault')
navMain.onclick = function () {
  navMain.classList.remove("show");
}    
